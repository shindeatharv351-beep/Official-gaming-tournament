<?php
// adept_play/my_tournaments.php
require_once __DIR__ . '/common/config.php';
checkUserAuth();

$userId = $_SESSION['user_id'];
$tab = $_GET['tab'] ?? 'upcoming';

// Fetch Live / Upcoming Joined Tournaments
$stmtActive = $pdo->prepare("
    SELECT t.* 
    FROM tournaments t
    JOIN participants p ON t.id = p.tournament_id
    WHERE p.user_id = ? AND t.status IN ('Upcoming', 'Live')
    ORDER BY t.match_time ASC
");
$stmtActive->execute([$userId]);
$activeTournaments = $stmtActive->fetchAll();

// Fetch Completed Joined Tournaments
$stmtCompleted = $pdo->prepare("
    SELECT t.* 
    FROM tournaments t
    JOIN participants p ON t.id = p.tournament_id
    WHERE p.user_id = ? AND t.status = 'Completed'
    ORDER BY t.match_time DESC
");
$stmtCompleted->execute([$userId]);
$completedTournaments = $stmtCompleted->fetchAll();

require_once __DIR__ . '/common/header.php';
?>

<!-- Two-Tab Layout Bar -->
<div class="flex bg-slate-950 p-1 rounded-2xl mb-4 border border-slate-800">
    <a href="my_tournaments.php?tab=upcoming" class="flex-1 text-center py-2.5 text-xs font-bold rounded-xl transition-all <?= ($tab === 'upcoming') ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold' : 'text-slate-400 hover:text-white' ?>">
        Upcoming / Live (<?= count($activeTournaments) ?>)
    </a>
    <a href="my_tournaments.php?tab=completed" class="flex-1 text-center py-2.5 text-xs font-bold rounded-xl transition-all <?= ($tab === 'completed') ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold' : 'text-slate-400 hover:text-white' ?>">
        Completed (<?= count($completedTournaments) ?>)
    </a>
</div>

<!-- Tab 1: Upcoming / Live -->
<?php if ($tab === 'upcoming'): ?>
    <?php if (empty($activeTournaments)): ?>
        <div class="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-8 text-center my-6">
            <i class="fa-solid fa-gamepad text-3xl text-slate-600 mb-2"></i>
            <p class="text-xs text-slate-400">You haven't joined any active matches yet.</p>
            <a href="index.php" class="inline-block mt-3 text-xs font-bold text-amber-400 hover:underline">Find a Match &rarr;</a>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php foreach ($activeTournaments as $item): ?>
                <div class="bg-slate-900 border <?= ($item['status'] === 'Live') ? 'border-red-500/50' : 'border-slate-800' ?> rounded-2xl p-4 shadow-md relative overflow-hidden">
                    
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md <?= ($item['status'] === 'Live') ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-indigo-500/10 text-indigo-400' ?>">
                            <?= ($item['status'] === 'Live') ? '🔴 LIVE NOW' : htmlspecialchars($item['game_name']) ?>
                        </span>
                        <span class="text-xs font-bold text-emerald-400">Pool: <?= formatINR($item['prize_pool']) ?></span>
                    </div>

                    <h4 class="text-sm font-bold text-white mb-1"><?= htmlspecialchars($item['title']) ?></h4>
                    <p class="text-xs text-slate-400 mb-3"><i class="fa-regular fa-clock text-amber-400 mr-1"></i><?= date('d M, h:i A', strtotime($item['match_time'])) ?></p>

                    <!-- Room Credentials Box (If Available) -->
                    <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                        <div class="flex items-center justify-between text-xs">
                            <span class="text-slate-400 font-medium">Room ID:</span>
                            <span class="font-mono font-bold text-amber-300">
                                <?= !empty($item['room_id']) ? htmlspecialchars($item['room_id']) : '<em class="text-slate-600 font-normal">Waiting for admin...</em>' ?>
                            </span>
                        </div>
                        <div class="flex items-center justify-between text-xs">
                            <span class="text-slate-400 font-medium">Password:</span>
                            <span class="font-mono font-bold text-amber-300">
                                <?= !empty($item['room_password']) ? htmlspecialchars($item['room_password']) : '<em class="text-slate-600 font-normal">Waiting for admin...</em>' ?>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

<!-- Tab 2: Completed -->
<?php else: ?>
    <?php if (empty($completedTournaments)): ?>
        <div class="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-8 text-center my-6">
            <i class="fa-solid fa-trophy text-3xl text-slate-600 mb-2"></i>
            <p class="text-xs text-slate-400">No match records completed yet.</p>
        </div>
    <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($completedTournaments as $item): ?>
                <?php $isWinner = ($item['winner_id'] == $userId); ?>
                <div class="bg-slate-900 border <?= $isWinner ? 'border-amber-500/40 bg-amber-500/5' : 'border-slate-800' ?> rounded-2xl p-4 flex items-center justify-between">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-[10px] text-slate-400"><?= htmlspecialchars($item['game_name']) ?></span>
                            <span class="text-[10px] text-slate-500">• <?= date('d M', strtotime($item['match_time'])) ?></span>
                        </div>
                        <h4 class="text-xs font-bold text-white mt-0.5"><?= htmlspecialchars($item['title']) ?></h4>
                        <span class="text-[11px] text-slate-400">Pool: <?= formatINR($item['prize_pool']) ?></span>
                    </div>

                    <div>
                        <?php if ($isWinner): ?>
                            <span class="px-3 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-black rounded-xl flex items-center space-x-1 shadow-sm">
                                <i class="fa-solid fa-crown text-amber-400"></i>
                                <span>Winner</span>
                            </span>
                        <?php else: ?>
                            <span class="px-3 py-1 bg-slate-800 text-slate-400 text-[11px] font-medium rounded-lg">
                                Participated
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>