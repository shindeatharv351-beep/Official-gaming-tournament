<?php
// adept_play/update_database.php
require_once __DIR__ . '/common/config.php';

$messages = [];
$error = false;

try {
    // 1. Create Settings Table for Admin UPI & QR Code
    $pdo->exec("CREATE TABLE IF NOT EXISTS `settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `setting_key` VARCHAR(50) NOT NULL UNIQUE,
        `setting_value` TEXT NULL
    ) ENGINE=InnoDB;");
    $messages[] = "Table `settings` verified/created.";

    // Insert default keys if not present
    $initSettings = [
        'admin_upi_id' => '',
        'admin_qr_code' => ''
    ];
    foreach ($initSettings as $k => $v) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES (?, ?)");
        $stmt->execute([$k, $v]);
    }

    // 2. Create Deposits Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `deposits` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `amount` DECIMAL(10,2) NOT NULL,
        `transaction_id` VARCHAR(100) NOT NULL,
        `status` ENUM('Pending', 'Completed', 'Rejected') NOT NULL DEFAULT 'Pending',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");
    $messages[] = "Table `deposits` verified/created.";

    // 3. Create Withdrawals Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `withdrawals` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `amount` DECIMAL(10,2) NOT NULL,
        `upi_id` VARCHAR(255) NOT NULL,
        `status` ENUM('Pending', 'Completed', 'Rejected') NOT NULL DEFAULT 'Pending',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");
    $messages[] = "Table `withdrawals` verified/created.";

    // 4. Safely add `upi_id` column to `users` table if missing
    $chkCol = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'upi_id'")->fetchAll();
    if (empty($chkCol)) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `upi_id` VARCHAR(255) NULL AFTER `email`;");
        $messages[] = "Column `upi_id` added to table `users`.";
    } else {
        $messages[] = "Column `upi_id` already exists in `users`.";
    }

    // 5. Ensure uploads directory exists
    $uploadDir = __DIR__ . '/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
        $messages[] = "Directory `/uploads` created.";
    }

} catch (Exception $e) {
    $error = true;
    $messages[] = "Database update error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Migration - Adept Play</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
        <h2 class="text-lg font-black text-amber-400 mb-3 flex items-center space-x-2">
            <span>⚙️ Schema Migration</span>
        </h2>
        <div class="space-y-2 mb-4 text-xs font-mono">
            <?php foreach ($messages as $msg): ?>
                <div class="p-2.5 rounded-xl <?= $error ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-slate-950 text-slate-300 border border-slate-800' ?>">
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (!$error): ?>
            <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-3.5 rounded-2xl mb-4 font-bold text-center">
                ✅ Database schema updated successfully! You can now safely delete this file.
            </div>
            <a href="wallet.php" class="block w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl text-center">
                Go to Wallet &rarr;
            </a>
        <?php endif; ?>
    </div>
</body>
</html>