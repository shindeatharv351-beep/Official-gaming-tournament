<?php
// adept_play/login.php
require_once __DIR__ . '/common/config.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';
$activeTab = 'login';

if (isset($_GET['installed'])) {
    $success = "Database installation successful! Log in or sign up to begin.";
}
if (isset($_GET['blocked'])) {
    $error = "Your account has been suspended by the administrator.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        $activeTab = 'login';
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = "Please fill in all fields.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if ($user['is_blocked']) {
                    $error = "Your account has been suspended.";
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    header("Location: index.php");
                    exit;
                }
            } else {
                $error = "Invalid username or password.";
            }
        }
    } elseif ($action === 'signup') {
        $activeTab = 'signup';
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($email) || empty($password)) {
            $error = "All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email address format.";
        } elseif (strlen($password) < 6) {
            $error = "Password must be at least 6 characters long.";
        } else {
            // Check if user already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                $error = "Username or Email is already registered.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                
                // Welcome bonus disabled: Initial balance is strictly 0.00
                $ins = $pdo->prepare("INSERT INTO users (username, email, password, wallet_balance) VALUES (?, ?, ?, 0.00)");
                $ins->execute([$username, $email, $hash]);
                
                $newUserId = $pdo->lastInsertId();

                $_SESSION['user_id'] = $newUserId;
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Adept Play - Access Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { -webkit-tap-highlight-color: transparent; user-select: none; }
    </style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        
        <!-- Decorative Glow -->
        <div class="absolute -top-12 -right-12 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl"></div>
        <div class="absolute -bottom-12 -left-12 w-32 h-32 bg-indigo-600/20 rounded-full blur-2xl"></div>

        <!-- Logo -->
        <div class="text-center mb-6 relative z-10">
            <div class="w-14 h-14 bg-gradient-to-tr from-amber-500 to-indigo-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-amber-500/20 mb-3">
                <i class="fa-solid fa-gamepad text-2xl text-white"></i>
            </div>
            <h2 class="text-2xl font-black tracking-tight text-white">Adept Play</h2>
            <p class="text-xs text-slate-400 mt-1">Compete • Dominate • Earn</p>
        </div>

        <!-- Error/Success Feedback -->
        <?php if (!empty($error)): ?>
            <div class="mb-4 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl p-3 flex items-center space-x-2">
                <i class="fa-solid fa-circle-exclamation text-sm"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="mb-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs rounded-xl p-3 flex items-center space-x-2">
                <i class="fa-solid fa-circle-check text-sm"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>

        <!-- Tabs Header -->
        <div class="flex bg-slate-950 p-1 rounded-xl mb-5 border border-slate-800">
            <button type="button" onclick="switchTab('login')" id="tab-btn-login" class="flex-1 py-2 text-xs font-bold rounded-lg transition-all <?= ($activeTab === 'login') ? 'bg-indigo-600 text-white shadow' : 'text-slate-400' ?>">
                Sign In
            </button>
            <button type="button" onclick="switchTab('signup')" id="tab-btn-signup" class="flex-1 py-2 text-xs font-bold rounded-lg transition-all <?= ($activeTab === 'signup') ? 'bg-indigo-600 text-white shadow' : 'text-slate-400' ?>">
                Register
            </button>
        </div>

        <!-- Login Form -->
        <form method="POST" action="login.php" id="form-login" class="<?= ($activeTab === 'login') ? 'block' : 'hidden' ?> space-y-4">
            <input type="hidden" name="action" value="login">
            <div>
                <label class="block text-xs font-medium text-slate-400 mb-1">Username or Email</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500"><i class="fa-regular fa-user text-xs"></i></span>
                    <input type="text" name="username" required class="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500" placeholder="pro_gamer">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-400 mb-1">Password</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500"><i class="fa-solid fa-lock text-xs"></i></span>
                    <input type="password" name="password" required class="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500" placeholder="••••••••">
                </div>
            </div>
            <button type="submit" class="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 active:scale-[0.98] transition-transform">
                Enter Arena
            </button>
        </form>

        <!-- Sign Up Form (Bonus Disabled) -->
        <form method="POST" action="login.php" id="form-signup" class="<?= ($activeTab === 'signup') ? 'block' : 'hidden' ?> space-y-4">
            <input type="hidden" name="action" value="signup">
            <div>
                <label class="block text-xs font-medium text-slate-400 mb-1">Username</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500"><i class="fa-solid fa-at text-xs"></i></span>
                    <input type="text" name="username" required class="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500" placeholder="player_one">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-400 mb-1">Email Address</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500"><i class="fa-regular fa-envelope text-xs"></i></span>
                    <input type="email" name="email" required class="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500" placeholder="player@adept.com">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-400 mb-1">Password (min 6 chars)</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500"><i class="fa-solid fa-key text-xs"></i></span>
                    <input type="password" name="password" required minlength="6" class="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500" placeholder="••••••••">
                </div>
            </div>
            <button type="submit" class="w-full py-3 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-indigo-600/30 active:scale-[0.98] transition-transform">
                Create Account
            </button>
        </form>

        <div class="mt-6 text-center border-t border-slate-800/80 pt-4">
            <a href="admin/login.php" class="text-[11px] text-slate-500 hover:text-slate-400 transition-colors">Admin Portal &rarr;</a>
        </div>
    </div>

    <script>
        function switchTab(tab) {
            const formLogin = document.getElementById('form-login');
            const formSignup = document.getElementById('form-signup');
            const btnLogin = document.getElementById('tab-btn-login');
            const btnSignup = document.getElementById('tab-btn-signup');

            if (tab === 'login') {
                formLogin.classList.remove('hidden');
                formSignup.classList.add('hidden');
                btnLogin.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all bg-indigo-600 text-white shadow";
                btnSignup.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all text-slate-400";
            } else {
                formSignup.classList.remove('hidden');
                formLogin.classList.add('hidden');
                btnSignup.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all bg-indigo-600 text-white shadow";
                btnLogin.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all text-slate-400";
            }
        }
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('selectstart', e => e.preventDefault());
    </script>
</body>
</html>