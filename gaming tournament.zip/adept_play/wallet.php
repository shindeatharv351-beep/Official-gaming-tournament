<?php
// adept_play/wallet.php
require_once __DIR__ . '/common/config.php';
checkUserAuth();

$userId = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Fetch Admin UPI Settings
$stmtSettings = $pdo->query("SELECT setting_key, setting_value FROM settings");
$settings = $stmtSettings->fetchAll(PDO::FETCH_KEY_PAIR);
$adminUpi = $settings['admin_upi_id'] ?? '';
$adminQr  = $settings['admin_qr_code'] ?? '';

// Fetch Current User Fresh Data
$stmtU = $pdo->prepare("SELECT wallet_balance, upi_id FROM users WHERE id = ?");
$stmtU->execute([$userId]);
$userData = $stmtU->fetch();
$userBalance = (float)$userData['wallet_balance'];
$userUpi = $userData['upi_id'] ?? '';

// 1. Handle Deposit Request Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_deposit') {
    $amount = (float)($_POST['amount'] ?? 0);
    $txnId  = trim($_POST['transaction_id'] ?? '');

    if ($amount < 10) {
        $message = "Minimum deposit amount is ₹10.00";
        $messageType = 'error';
    } elseif (empty($txnId)) {
        $message = "Please enter the UPI Transaction ID / UTR.";
        $messageType = 'error';
    } else {
        // Prevent duplicate UTR submission
        $chkTx = $pdo->prepare("SELECT id FROM deposits WHERE transaction_id = ?");
        $chkTx->execute([$txnId]);
        if ($chkTx->fetch()) {
            $message = "This Transaction ID has already been submitted.";
            $messageType = 'error';
        } else {
            $ins = $pdo->prepare("INSERT INTO deposits (user_id, amount, transaction_id, status) VALUES (?, ?, ?, 'Pending')");
            $ins->execute([$userId, $amount, $txnId]);
            $message = "Deposit request for " . formatINR($amount) . " submitted! It will be verified by admin shortly.";
            $messageType = 'success';
        }
    }
}

// 2. Handle Withdrawal Request Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_withdrawal') {
    $amount = (float)($_POST['amount'] ?? 0);

    if (empty($userUpi)) {
        $message = "Please save your UPI ID in your Profile before requesting a withdrawal.";
        $messageType = 'error';
    } elseif ($amount < 50) {
        $message = "Minimum withdrawal amount is ₹50.00";
        $messageType = 'error';
    } elseif ($amount > $userBalance) {
        $message = "Insufficient wallet balance!";
        $messageType = 'error';
    } else {
        // Deduct from wallet immediately so it cannot be double-spent
        $pdo->beginTransaction();
        $upd = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
        $upd->execute([$amount, $userId]);

        $insW = $pdo->prepare("INSERT INTO withdrawals (user_id, amount, upi_id, status) VALUES (?, ?, ?, 'Pending')");
        $insW->execute([$userId, $amount, $userUpi]);

        $pdo->commit();
        $userBalance -= $amount;

        $message = "Withdrawal request for " . formatINR($amount) . " submitted! Sent to verification queue.";
        $messageType = 'success';
    }
}

// Fetch transaction history
$stmtTx = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 20");
$stmtTx->execute([$userId]);
$transactions = $stmtTx->fetchAll();

require_once __DIR__ . '/common/header.php';
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?> text-sm"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<!-- Big Wallet Card -->
<div class="relative bg-gradient-to-tr from-amber-500 via-amber-600 to-indigo-700 rounded-3xl p-5 text-white shadow-xl shadow-amber-500/10 mb-5 overflow-hidden">
    <div class="relative z-10">
        <span class="text-xs uppercase font-extrabold tracking-wider opacity-80">Available Balance</span>
        <div class="text-3xl font-black mt-1"><?= formatINR($userBalance) ?></div>
        <p class="text-[11px] opacity-90 mt-1">Player ID: #100<?= $currentUser['id'] ?></p>
    </div>
    <div class="absolute -right-6 -bottom-6 text-white/15 text-9xl font-black pointer-events-none">
        <i class="fa-solid fa-coins"></i>
    </div>
</div>

<!-- Functional Add & Withdraw Trigger Buttons -->
<div class="grid grid-cols-2 gap-3 mb-6">
    <button type="button" onclick="openModal('deposit-modal')" class="py-3 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-2xl shadow-lg shadow-emerald-600/20 flex items-center justify-center space-x-1.5 transition-all">
        <i class="fa-solid fa-circle-plus text-sm"></i>
        <span>Add Money</span>
    </button>
    <button type="button" onclick="openModal('withdraw-modal')" class="py-3 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs rounded-2xl shadow-lg shadow-indigo-600/20 flex items-center justify-center space-x-1.5 transition-all">
        <i class="fa-solid fa-arrow-up-from-bracket text-sm"></i>
        <span>Withdraw</span>
    </button>
</div>

<!-- ================= DEPOSIT MODAL ================= -->
<div id="deposit-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <!-- Close Button -->
        <button type="button" onclick="closeModal('deposit-modal')" class="absolute top-4 right-4 text-slate-400 hover:text-white">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-sm font-black text-white mb-1 flex items-center space-x-1.5">
            <i class="fa-solid fa-qrcode text-amber-400"></i>
            <span>Add Money via UPI</span>
        </h3>
        <p class="text-[11px] text-slate-400 mb-3">Scan the QR code or pay to the UPI ID below:</p>

        <!-- QR Code Display -->
        <div class="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-center mb-3">
            <?php if (!empty($adminQr) && file_exists(__DIR__ . '/' . $adminQr)): ?>
                <img src="<?= htmlspecialchars($adminQr) ?>" alt="UPI QR Code" class="w-36 h-36 mx-auto object-contain rounded-xl bg-white p-1 mb-2">
            <?php else: ?>
                <div class="w-36 h-36 mx-auto bg-slate-900 rounded-xl flex flex-col items-center justify-center text-slate-600 text-xs p-2 mb-2 border border-dashed border-slate-800">
                    <i class="fa-solid fa-qrcode text-3xl mb-1"></i>
                    <span>QR Pending Admin Setup</span>
                </div>
            <?php endif; ?>

            <div class="text-[11px] text-slate-400">Admin UPI ID:</div>
            <div class="font-mono text-xs font-bold text-amber-300 select-all">
                <?= !empty($adminUpi) ? htmlspecialchars($adminUpi) : 'admin@upi (Contact Admin)' ?>
            </div>
        </div>

        <!-- Deposit Request Form -->
        <form method="POST" action="wallet.php" class="space-y-3">
            <input type="hidden" name="action" value="submit_deposit">
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Amount Paid (₹)</label>
                <input type="number" name="amount" min="10" step="1" required placeholder="e.g. 100" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500">
            </div>
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">UPI Ref / Transaction ID (UTR)</label>
                <input type="text" name="transaction_id" required placeholder="12-digit UPI reference number" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500">
            </div>
            <button type="submit" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                Submit Deposit Request
            </button>
        </form>
    </div>
</div>

<!-- ================= WITHDRAW MODAL ================= -->
<div id="withdraw-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative">
        <!-- Close Button -->
        <button type="button" onclick="closeModal('withdraw-modal')" class="absolute top-4 right-4 text-slate-400 hover:text-white">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <h3 class="text-sm font-black text-white mb-1 flex items-center space-x-1.5">
            <i class="fa-solid fa-arrow-up-from-bracket text-indigo-400"></i>
            <span>Withdraw to Bank UPI</span>
        </h3>
        <p class="text-[11px] text-slate-400 mb-3">Direct withdrawal to your saved UPI address.</p>

        <?php if (empty($userUpi)): ?>
            <div class="bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl text-xs text-amber-300 mb-4 text-center">
                <i class="fa-solid fa-circle-info mr-1"></i> You haven't added your UPI ID yet.
                <a href="profile.php" class="block mt-2 font-bold underline text-white">Go to Profile to Add UPI &rarr;</a>
            </div>
        <?php else: ?>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 mb-3 text-xs">
                <span class="text-slate-400">Payout UPI ID:</span>
                <span class="font-bold text-amber-300 ml-1"><?= htmlspecialchars($userUpi) ?></span>
                <a href="profile.php" class="text-[10px] text-indigo-400 block mt-0.5 hover:underline">Change in profile</a>
            </div>

            <form method="POST" action="wallet.php" class="space-y-3">
                <input type="hidden" name="action" value="submit_withdrawal">
                <div>
                    <label class="block text-[11px] text-slate-400 mb-1">Amount to Withdraw (₹)</label>
                    <input type="number" name="amount" min="50" max="<?= $userBalance ?>" step="1" required placeholder="Min ₹50" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
                    <span class="text-[10px] text-slate-500 mt-1 block">Available: <?= formatINR($userBalance) ?></span>
                </div>
                <button type="submit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                    Request Payout
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<!-- Transaction History Section -->
<h3 class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Recent Transactions</h3>
<?php if (empty($transactions)): ?>
    <div class="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-6 text-center">
        <p class="text-xs text-slate-500">No transactions recorded yet.</p>
    </div>
<?php else: ?>
    <div class="space-y-2.5">
        <?php foreach ($transactions as $tx): ?>
            <div class="bg-slate-900 border border-slate-800/80 rounded-2xl p-3 flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-9 h-9 rounded-xl flex items-center justify-center <?= ($tx['type'] === 'credit') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400' ?>">
                        <i class="fa-solid <?= ($tx['type'] === 'credit') ? 'fa-arrow-down-left' : 'fa-arrow-up-right' ?> text-sm"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-white leading-tight"><?= htmlspecialchars($tx['description']) ?></p>
                        <span class="text-[10px] text-slate-500"><?= date('d M Y, h:i A', strtotime($tx['created_at'])) ?></span>
                    </div>
                </div>
                <div class="text-right">
                    <span class="text-xs font-black <?= ($tx['type'] === 'credit') ? 'text-emerald-400' : 'text-slate-300' ?>">
                        <?= ($tx['type'] === 'credit') ? '+' : '-' ?> <?= formatINR($tx['amount']) ?>
                    </span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
    function openModal(id) {
        document.getElementById(id).classList.remove('hidden');
    }
    function closeModal(id) {
        document.getElementById(id).classList.add('hidden');
    }
</script>

<?php require_once __DIR__ . '/common/bottom.php'; ?>