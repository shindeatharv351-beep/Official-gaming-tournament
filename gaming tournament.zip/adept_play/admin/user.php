<?php
// adept_play/admin/user.php
require_once __DIR__ . '/common/header.php';

$message = '';

// Block / Unblock Toggle via GET
if (isset($_GET['action']) && isset($_GET['id'])) {
    $targetId = (int)$_GET['id'];
    if ($_GET['action'] === 'block') {
        $upd = $pdo->prepare("UPDATE users SET is_blocked = 1 WHERE id = ?");
        $upd->execute([$targetId]);
        $message = "User #$targetId blocked successfully.";
    } elseif ($_GET['action'] === 'unblock') {
        $upd = $pdo->prepare("UPDATE users SET is_blocked = 0 WHERE id = ?");
        $upd->execute([$targetId]);
        $message = "User #$targetId unblocked.";
    }
}

// Fetch all registered users with match counts
$users = $pdo->query("
    SELECT u.*, 
           (SELECT COUNT(*) FROM participants WHERE user_id = u.id) as matches_played
    FROM users u
    ORDER BY u.id DESC
")->fetchAll();
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs bg-indigo-500/10 border border-indigo-500/30 text-indigo-300">
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
    <h2 class="text-base font-bold text-white">Registered Users</h2>
    <span class="text-xs text-slate-400"><?= count($users) ?> total</span>
</div>

<div class="space-y-3">
    <?php foreach ($users as $u): ?>
        <div class="bg-slate-900 border <?= $u['is_blocked'] ? 'border-red-500/40 bg-red-500/5' : 'border-slate-800' ?> rounded-2xl p-3.5 shadow-sm">
            <div class="flex items-start justify-between">
                <div>
                    <div class="flex items-center space-x-2">
                        <h4 class="text-xs font-bold text-white"><?= htmlspecialchars($u['username']) ?></h4>
                        <?php if ($u['is_blocked']): ?>
                            <span class="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[9px] font-black rounded uppercase">Suspended</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-[11px] text-slate-400"><?= htmlspecialchars($u['email']) ?></p>
                </div>
                <div class="text-right">
                    <span class="text-[10px] text-slate-400 uppercase">Wallet</span>
                    <p class="text-xs font-bold text-amber-300"><?= formatINR($u['wallet_balance']) ?></p>
                </div>
            </div>

            <div class="flex items-center justify-between mt-3 pt-2 border-t border-slate-800 text-[11px]">
                <span class="text-slate-500"><i class="fa-solid fa-gamepad mr-1"></i><?= $u['matches_played'] ?> matches</span>
                <div>
                    <?php if ($u['is_blocked']): ?>
                        <a href="user.php?action=unblock&id=<?= $u['id'] ?>" class="text-emerald-400 font-bold hover:underline">Unblock</a>
                    <?php else: ?>
                        <a href="user.php?action=block&id=<?= $u['id'] ?>" onclick="return confirm('Suspend user <?= htmlspecialchars($u['username']) ?>?');" class="text-red-400 font-bold hover:underline">Block User</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/common/bottom.php'; ?>