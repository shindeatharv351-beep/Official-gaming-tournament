<?php
// admin/manage_tournament.php
require_once __DIR__ . '/common/header.php';

$tournamentId = (int)($_GET['id'] ?? 0);
$message = '';
$messageType = '';

// Safely ensure slot_no column exists
$chkSlot = $pdo->query("SHOW COLUMNS FROM `participants` LIKE 'slot_no'")->fetchAll();
if (empty($chkSlot)) {
    $pdo->exec("ALTER TABLE `participants` ADD COLUMN `slot_no` INT NOT NULL DEFAULT 1 AFTER `tournament_id`;");
}

// 1. Handle Room ID & Status Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_room') {
    $roomId   = trim($_POST['room_id'] ?? '');
    $roomPass = trim($_POST['room_password'] ?? '');
    $status   = $_POST['status'] ?? 'Upcoming';

    $upd = $pdo->prepare("UPDATE tournaments SET room_id = ?, room_password = ?, status = ? WHERE id = ?");
    $upd->execute([$roomId, $roomPass, $status, $tournamentId]);
    $message = "Room credentials and match status updated!";
    $messageType = 'success';
}

// 2. Handle Setting Winning Amount & Rewarding Player (1 to 100)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'distribute_prize') {
    $winnerUserId  = (int)($_POST['winner_user_id'] ?? 0);
    $winningAmount = (float)($_POST['winning_amount'] ?? 0);
    $winningTitle  = trim($_POST['winning_title'] ?? 'Match Winner');
    $markCompleted = isset($_POST['mark_completed']);

    // Fetch tournament details
    $tmt = $pdo->prepare("SELECT * FROM tournaments WHERE id = ?");
    $tmt->execute([$tournamentId]);
    $currentT = $tmt->fetch();

    if (!$currentT) {
        $message = "Tournament not found.";
        $messageType = 'error';
    } elseif ($winnerUserId <= 0) {
        $message = "Please choose a participant from Slot 1 to 100.";
        $messageType = 'error';
    } elseif ($winningAmount <= 0) {
        $message = "Please enter a valid winning amount greater than ₹0.";
        $messageType = 'error';
    } else {
        $pdo->beginTransaction();

        // 1. Credit the winning amount to the selected player's wallet
        $updUser = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
        $updUser->execute([$winningAmount, $winnerUserId]);

        // 2. Insert credit transaction for the user
        $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)");
        $txDesc = "$winningTitle Prize for #" . $currentT['id'] . " (" . $currentT['title'] . ")";
        $tx->execute([$winnerUserId, $winningAmount, $txDesc]);

        // 3. Mark tournament status if requested
        if ($markCompleted) {
            $updT = $pdo->prepare("UPDATE tournaments SET winner_id = ?, status = 'Completed' WHERE id = ?");
            $updT->execute([$winnerUserId, $tournamentId]);
        }

        $pdo->commit();
        $message = "✅ Credited " . formatINR($winningAmount) . " ($winningTitle) to Player's wallet!";
        $messageType = 'success';
    }
}

// Fetch single tournament
$stmt = $pdo->prepare("SELECT * FROM tournaments WHERE id = ?");
$stmt->execute([$tournamentId]);
$tournament = $stmt->fetch();

if (!$tournament) {
    echo "<div class='p-4 text-xs text-red-400'>Tournament not found. <a href='tournament.php' class='underline'>Back</a></div>";
    require_once __DIR__ . '/common/bottom.php';
    exit;
}

// Fetch all joined participants with their Slot Number (1 to 100), IGN, and UID
$stmtParticipants = $pdo->prepare("
    SELECT u.id as user_id, u.username, p.id as participant_id, p.slot_no, p.in_game_name, p.in_game_id, p.created_at as joined_at
    FROM participants p
    JOIN users u ON p.user_id = u.id
    WHERE p.tournament_id = ?
    ORDER BY p.slot_no ASC, p.id ASC
");
$stmtParticipants->execute([$tournamentId]);
$participants = $stmtParticipants->fetchAll();
$maxPlayers = (int)($tournament['max_players'] ?? 100);
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<!-- Tournament Overview Card -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-4 mb-4 shadow-lg">
    <div class="flex items-center justify-between mb-1">
        <span class="text-[10px] uppercase font-bold text-indigo-400"><?= htmlspecialchars($tournament['game_name']) ?></span>
        <span class="text-[10px] font-bold px-2 py-0.5 rounded <?= ($tournament['status'] === 'Completed') ? 'bg-slate-800 text-slate-400' : 'bg-amber-500/10 text-amber-400' ?>">
            <?= $tournament['status'] ?>
        </span>
    </div>
    <h3 class="text-sm font-black text-white"><?= htmlspecialchars($tournament['title']) ?></h3>
    <div class="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 text-xs">
        <div>Total Pool: <strong class="text-emerald-400 block"><?= formatINR($tournament['prize_pool']) ?></strong></div>
        <div>Entry: <strong class="text-white block"><?= formatINR($tournament['entry_fee']) ?></strong></div>
        <div class="text-right">Slots: <strong class="text-amber-300 block"><?= count($participants) ?> / <?= $maxPlayers ?></strong></div>
    </div>
</div>

<!-- ================= SET WINNING AMOUNT & REWARD PLAYER ================= -->
<div class="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 mb-4 shadow-xl">
    <div class="flex items-center space-x-2 mb-1">
        <div class="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center text-sm">
            <i class="fa-solid fa-crown"></i>
        </div>
        <div>
            <h4 class="text-xs font-bold text-amber-400 uppercase tracking-wider">Set Winning Amount & Reward Player</h4>
            <p class="text-[10px] text-slate-400">Award prize money to any player (Slot 1 to <?= $maxPlayers ?>)</p>
        </div>
    </div>

    <form method="POST" action="manage_tournament.php?id=<?= $tournament['id'] ?>" onsubmit="return confirm('Confirm prize distribution? The amount will be instantly credited to the player.');" class="space-y-3 mt-3">
        <input type="hidden" name="action" value="distribute_prize">

        <!-- Select Player from 1 to 100 -->
        <div>
            <label class="block text-[11px] font-bold text-slate-300 mb-1">Select Winning Player</label>
            <select name="winner_user_id" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono">
                <option value="">-- Choose Player (Slot 1 to <?= count($participants) ?>) --</option>
                <?php foreach ($participants as $idx => $p): ?>
                    <option value="<?= $p['user_id'] ?>">
                        Slot #<?= $p['slot_no'] ?: ($idx + 1) ?>: <?= htmlspecialchars($p['username']) ?> 
                        (IGN: <?= htmlspecialchars($p['in_game_name'] ?? 'N/A') ?> - UID: <?= htmlspecialchars($p['in_game_id'] ?? 'N/A') ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="grid grid-cols-2 gap-2">
            <!-- Winning Amount Field -->
            <div>
                <label class="block text-[11px] font-bold text-emerald-400 mb-1">Set Winning Amount (₹)</label>
                <input 
                    type="number" 
                    name="winning_amount" 
                    step="0.01" 
                    min="1" 
                    value="<?= $tournament['prize_pool'] ?>" 
                    required 
                    placeholder="e.g. 100" 
                    class="w-full bg-slate-950 border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-emerald-300 font-bold focus:outline-none focus:border-emerald-400"
                >
            </div>

            <!-- Rank/Title (e.g. 1st Place / Per Kill) -->
            <div>
                <label class="block text-[11px] font-bold text-slate-300 mb-1">Rank / Title</label>
                <input 
                    type="text" 
                    name="winning_title" 
                    value="1st Place (Winner)" 
                    required 
                    placeholder="e.g. 1st Place, 2nd, 5 Kills" 
                    class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
            </div>
        </div>

        <!-- Optional Checkbox: Complete Match -->
        <label class="flex items-center space-x-2 text-[11px] text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800 cursor-pointer">
            <input type="checkbox" name="mark_completed" value="1" class="rounded text-amber-500 focus:ring-0">
            <span>Mark tournament as <strong>Completed</strong> after sending this prize</span>
        </label>

        <button type="submit" <?= empty($participants) ? 'disabled' : '' ?> class="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-50">
            Credit Winning Amount to Player
        </button>
    </form>
</div>

<!-- Room Details Form -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-4 mb-4">
    <h4 class="text-xs font-bold text-white uppercase tracking-wider mb-3">Room Access & State</h4>
    <form method="POST" action="manage_tournament.php?id=<?= $tournament['id'] ?>" class="space-y-3">
        <input type="hidden" name="action" value="update_room">
        <div class="grid grid-cols-2 gap-2">
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Room ID</label>
                <input type="text" name="room_id" value="<?= htmlspecialchars($tournament['room_id'] ?? '') ?>" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="e.g. 5421998">
            </div>
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Room Password</label>
                <input type="text" name="room_password" value="<?= htmlspecialchars($tournament['room_password'] ?? '') ?>" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="e.g. 1234">
            </div>
        </div>
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Match Status</label>
            <select name="status" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                <option value="Upcoming" <?= ($tournament['status'] === 'Upcoming') ? 'selected' : '' ?>>Upcoming</option>
                <option value="Live" <?= ($tournament['status'] === 'Live') ? 'selected' : '' ?>>Live (In-Progress)</option>
                <option value="Completed" <?= ($tournament['status'] === 'Completed') ? 'selected' : '' ?>>Completed</option>
            </select>
        </div>
        <button type="submit" class="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors">
            Update Room & Status
        </button>
    </form>
</div>

<!-- ================= PARTICIPANTS LIST (SLOTS 1 TO 100) ================= -->
<div class="flex items-center justify-between mb-2 px-1">
    <h4 class="text-xs font-bold text-slate-300 uppercase tracking-wider">
        Player Slots (<?= count($participants) ?> / <?= $maxPlayers ?>)
    </h4>
</div>

<?php if (empty($participants)): ?>
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
        No users have joined this match yet.
    </div>
<?php else: ?>
    <div class="space-y-2">
        <?php foreach ($participants as $idx => $p): ?>
            <?php $slotNumber = $p['slot_no'] ?: ($idx + 1); ?>
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between text-xs shadow-sm">
                <div>
                    <div class="flex items-center space-x-2">
                        <span class="px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] font-mono font-black">
                            Slot #<?= $slotNumber ?>
                        </span>
                        <span class="font-bold text-white"><?= htmlspecialchars($p['username']) ?></span>
                    </div>
                    <div class="text-[11px] text-slate-400 font-mono mt-1 ml-1">
                        IGN: <strong class="text-white"><?= htmlspecialchars($p['in_game_name'] ?? 'N/A') ?></strong> | 
                        UID: <strong class="text-white"><?= htmlspecialchars($p['in_game_id'] ?? 'N/A') ?></strong>
                    </div>
                </div>
                <span class="text-[10px] text-slate-500"><?= date('h:i A', strtotime($p['joined_at'])) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>