<?php
// adept_play/admin/deposits.php
require_once __DIR__ . '/common/header.php';

$message = '';
$messageType = '';

// Handle Approve / Reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deposit_id'], $_POST['action_type'])) {
    $depositId = (int)$_POST['deposit_id'];
    $actionType = $_POST['action_type'];

    $stmtD = $pdo->prepare("SELECT d.*, u.username FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.id = ?");
    $stmtD->execute([$depositId]);
    $dep = $stmtD->fetch();

    if (!$dep) {
        $message = "Deposit request not found.";
        $messageType = 'error';
    } elseif ($dep['status'] !== 'Pending') {
        $message = "This request has already been processed as " . $dep['status'] . ".";
        $messageType = 'error';
    } else {
        if ($actionType === 'approve') {
            $pdo->beginTransaction();
            // 1. Mark Deposit as Completed
            $upd = $pdo->prepare("UPDATE deposits SET status = 'Completed' WHERE id = ?");
            $upd->execute([$depositId]);

            // 2. Add Balance to user's wallet
            $updUser = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
            $updUser->execute([$dep['amount'], $dep['user_id']]);

            // 3. Insert transaction record
            $desc = "Deposit Approved (Ref: " . $dep['transaction_id'] . ")";
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)");
            $tx->execute([$dep['user_id'], $dep['amount'], $desc]);

            $pdo->commit();
            $message = "Deposit of " . formatINR($dep['amount']) . " for " . htmlspecialchars($dep['username']) . " approved successfully!";
            $messageType = 'success';
        } elseif ($actionType === 'reject') {
            $upd = $pdo->prepare("UPDATE deposits SET status = 'Rejected' WHERE id = ?");
            $upd->execute([$depositId]);
            $message = "Deposit request #$depositId was rejected.";
            $messageType = 'success';
        }
    }
}

// Fetch all requests (Pending first)
$deposits = $pdo->query("
    SELECT d.*, u.username, u.email 
    FROM deposits d 
    JOIN users u ON d.user_id = u.id 
    ORDER BY CASE WHEN d.status = 'Pending' THEN 1 ELSE 2 END, d.id DESC
")->fetchAll();
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
    <h2 class="text-base font-black text-white">Deposit Requests</h2>
    <span class="text-xs text-slate-400"><?= count($deposits) ?> total</span>
</div>

<?php if (empty($deposits)): ?>
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-500">
        No deposit requests found.
    </div>
<?php else: ?>
    <div class="space-y-3">
        <?php foreach ($deposits as $d): ?>
            <div class="bg-slate-900 border <?= ($d['status'] === 'Pending') ? 'border-amber-500/40 bg-amber-500/5' : 'border-slate-800' ?> rounded-2xl p-4 shadow-sm">
                <div class="flex items-start justify-between">
                    <div>
                        <span class="text-xs font-bold text-white"><?= htmlspecialchars($d['username']) ?></span>
                        <div class="text-[11px] font-mono text-amber-300 mt-0.5">
                            Ref / UTR: <strong class="text-white select-all"><?= htmlspecialchars($d['transaction_id']) ?></strong>
                        </div>
                        <span class="text-[10px] text-slate-500"><?= date('d M Y, h:i A', strtotime($d['created_at'])) ?></span>
                    </div>
                    <div class="text-right">
                        <span class="text-sm font-black text-emerald-400"><?= formatINR($d['amount']) ?></span>
                        <div>
                            <span class="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full <?= ($d['status'] === 'Pending') ? 'bg-amber-500/20 text-amber-300' : (($d['status'] === 'Completed') ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400') ?>">
                                <?= $d['status'] ?>
                            </span>
                        </div>
                    </div>
                </div>

                <?php if ($d['status'] === 'Pending'): ?>
                    <div class="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800">
                        <form method="POST" action="deposits.php">
                            <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
                            <input type="hidden" name="action_type" value="approve">
                            <button type="submit" onclick="return confirm('Approve payment of <?= formatINR($d['amount']) ?> for <?= htmlspecialchars($d['username']) ?>?');" class="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                                <i class="fa-solid fa-check mr-1"></i> Approve
                            </button>
                        </form>
                        <form method="POST" action="deposits.php">
                            <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
                            <input type="hidden" name="action_type" value="reject">
                            <button type="submit" onclick="return confirm('Reject this deposit request?');" class="w-full py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                                <i class="fa-solid fa-xmark mr-1"></i> Reject
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>