<?php
// admin/settings.php
require_once __DIR__ . '/common/header.php';

$message = '';
$messageType = '';
$adminId = $_SESSION['admin_id'] ?? 1;

// Ensure settings table exists
$pdo->exec("CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(50) NOT NULL UNIQUE,
    `setting_value` TEXT NULL
) ENGINE=InnoDB;");

// 1. Handle Admin UPI & QR Code Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_payment_settings') {
    $upiId = trim($_POST['admin_upi_id'] ?? '');

    // Save UPI ID
    $updUpi = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('admin_upi_id', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $updUpi->execute([$upiId, $upiId]);

    // Handle QR Code Upload
    if (isset($_FILES['qr_code']) && $_FILES['qr_code']['error'] === UPLOAD_ERR_OK) {
        $fileTmp  = $_FILES['qr_code']['tmp_name'];
        $fileName = $_FILES['qr_code']['name'];
        $fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed  = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($fileExt, $allowed)) {
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $newFileName = 'admin_qr_' . time() . '.' . $fileExt;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmp, $destPath)) {
                $savedPath = 'uploads/' . $newFileName;
                $updQr = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('admin_qr_code', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                $updQr->execute([$savedPath, $savedPath]);
            }
        }
    }

    $message = "Payment & QR settings updated successfully!";
    $messageType = 'success';
}

// 2. Handle Admin Password Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_admin_pass') {
    $curr = $_POST['current_password'] ?? '';
    $new  = $_POST['new_password'] ?? '';

    $stmt = $pdo->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->execute([$adminId]);
    $hash = $stmt->fetchColumn();

    if (!password_verify($curr, $hash)) {
        $message = "Current admin password incorrect.";
        $messageType = 'error';
    } elseif (strlen($new) < 6) {
        $message = "New password must be at least 6 characters.";
        $messageType = 'error';
    } else {
        $newHash = password_hash($new, PASSWORD_BCRYPT);
        $upd = $pdo->prepare("UPDATE admin SET password = ? WHERE id = ?");
        $upd->execute([$newHash, $adminId]);
        $message = "Admin password updated successfully!";
        $messageType = 'success';
    }
}

// Fetch Admin Info & Settings
$stmtAdm = $pdo->prepare("SELECT username FROM admin WHERE id = ?");
$stmtAdm->execute([$adminId]);
$adminUsername = $stmtAdm->fetchColumn() ?: 'admin';

$stmtSettings = $pdo->query("SELECT setting_key, setting_value FROM settings");
$settings = $stmtSettings->fetchAll(PDO::FETCH_KEY_PAIR);
$currentUpi = $settings['admin_upi_id'] ?? '';
$currentQr  = $settings['admin_qr_code'] ?? '';
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<div class="mb-4">
    <h2 class="text-base font-black text-white">Admin Settings</h2>
    <p class="text-xs text-slate-400">Manage payment gateways, security, and account</p>
</div>

<!-- 1. Admin Profile Banner -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-4 mb-5 flex items-center justify-between shadow-md">
    <div class="flex items-center space-x-3">
        <div class="w-11 h-11 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold text-base border border-amber-500/20">
            <i class="fa-solid fa-user-shield"></i>
        </div>
        <div>
            <h4 class="text-xs font-bold text-white"><?= htmlspecialchars($adminUsername) ?></h4>
            <span class="text-[10px] text-amber-400 font-semibold tracking-wide uppercase">Super Administrator</span>
        </div>
    </div>
    <a href="login.php?action=logout" class="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-bold rounded-xl transition-colors">
        <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i> Logout
    </a>
</div>

<!-- 2. Payment & QR Setup Section -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg mb-5">
    <h3 class="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center space-x-1.5">
        <i class="fa-solid fa-qrcode"></i>
        <span>Deposit Settings (UPI & QR)</span>
    </h3>
    <form method="POST" action="settings.php" enctype="multipart/form-data" class="space-y-4">
        <input type="hidden" name="action" value="update_payment_settings">

        <div>
            <label class="block text-[11px] font-bold text-slate-300 mb-1">Admin UPI ID</label>
            <input type="text" name="admin_upi_id" value="<?= htmlspecialchars($currentUpi) ?>" required placeholder="e.g. 9876543210@paytm or name@oksbi" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
        </div>

        <div>
            <label class="block text-[11px] font-bold text-slate-300 mb-1">QR Code Image</label>
            <?php if (!empty($currentQr) && file_exists(__DIR__ . '/../' . $currentQr)): ?>
                <div class="bg-slate-950 border border-slate-800 p-2.5 rounded-xl mb-2 flex items-center space-x-3">
                    <img src="../<?= htmlspecialchars($currentQr) ?>" alt="Current QR" class="w-16 h-16 object-contain rounded-lg bg-white p-1">
                    <div>
                        <span class="text-[11px] font-bold text-emerald-400">Current QR Active</span>
                        <p class="text-[10px] text-slate-500">Upload a new file below to replace it.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-slate-950 border border-dashed border-slate-800 p-3 rounded-xl mb-2 text-center text-[11px] text-slate-500">
                    No custom QR code image uploaded yet.
                </div>
            <?php endif; ?>

            <input type="file" name="qr_code" accept="image/png, image/jpeg, image/webp" class="w-full text-xs text-slate-400 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-slate-800 file:text-white cursor-pointer">
        </div>

        <button type="submit" class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-all uppercase tracking-wider">
            Save Payment Details
        </button>
    </form>
</div>

<!-- 3. Change Admin Password Section -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg mb-5">
    <h3 class="text-xs font-bold text-white uppercase tracking-wider mb-3 flex items-center space-x-1.5">
        <i class="fa-solid fa-key text-indigo-400"></i>
        <span>Change Admin Password</span>
    </h3>
    <form method="POST" action="settings.php" class="space-y-3">
        <input type="hidden" name="action" value="change_admin_pass">
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Current Password</label>
            <input type="password" name="current_password" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
        </div>
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">New Password (min 6 characters)</label>
            <input type="password" name="new_password" minlength="6" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
        </div>
        <button type="submit" class="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-colors">
            Update Password
        </button>
    </form>
</div>

<!-- 4. Quick Action Links -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
    <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Quick Management</h3>
    <div class="grid grid-cols-2 gap-2">
        <a href="user.php" class="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl flex items-center space-x-2 text-xs text-white transition-colors">
            <i class="fa-solid fa-users text-indigo-400"></i>
            <span>Manage Users</span>
        </a>
        <a href="tournament.php" class="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-2xl flex items-center space-x-2 text-xs text-white transition-colors">
            <i class="fa-solid fa-gamepad text-amber-400"></i>
            <span>Add Match</span>
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/common/bottom.php'; ?>