<?php
// admin/tournament.php
require_once __DIR__ . '/common/header.php';

// Automatically add 'max_players' and 'match_rules' columns if they don't exist yet
$chkCol = $pdo->query("SHOW COLUMNS FROM `tournaments` LIKE 'max_players'")->fetchAll();
if (empty($chkCol)) {
    $pdo->exec("ALTER TABLE `tournaments` ADD COLUMN `max_players` INT NOT NULL DEFAULT 100 AFTER `commission_percentage`;");
}

$chkRulesCol = $pdo->query("SHOW COLUMNS FROM `tournaments` LIKE 'match_rules'")->fetchAll();
if (empty($chkRulesCol)) {
    $pdo->exec("ALTER TABLE `tournaments` ADD COLUMN `match_rules` TEXT NULL AFTER `max_players`;");
}

$message = '';
$messageType = '';

// Handle Delete Action
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $delId = (int)$_GET['id'];
    $del = $pdo->prepare("DELETE FROM tournaments WHERE id = ?");
    $del->execute([$delId]);
    $delP = $pdo->prepare("DELETE FROM participants WHERE tournament_id = ?");
    $delP->execute([$delId]);

    $message = "Tournament #$delId deleted successfully!";
    $messageType = 'success';
}

// Handle Add Tournament
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_tournament') {
    $title         = trim($_POST['title'] ?? '');
    $game_name     = trim($_POST['game_name'] ?? '');
    $entry_fee     = (float)($_POST['entry_fee'] ?? 0);
    $prize_pool    = (float)($_POST['prize_pool'] ?? 0);
    $match_time    = $_POST['match_time'] ?? '';
    $commission    = (float)($_POST['commission_percentage'] ?? 0);
    $max_players   = (int)($_POST['max_players'] ?? 100);
    $match_rules   = trim($_POST['match_rules'] ?? '');

    if ($max_players <= 0) {
        $max_players = 100;
    }

    if (empty($title) || empty($game_name) || empty($match_time)) {
        $message = "Please fill in all required fields.";
        $messageType = 'error';
    } else {
        $ins = $pdo->prepare("INSERT INTO tournaments (title, game_name, entry_fee, prize_pool, commission_percentage, max_players, match_rules, match_time, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Upcoming')");
        $ins->execute([$title, $game_name, $entry_fee, $prize_pool, $commission, $max_players, $match_rules, $match_time]);
        $message = "Tournament created successfully with match rules!";
        $messageType = 'success';
    }
}

// Fetch all tournaments with participant count
$tournaments = $pdo->query("
    SELECT t.*, 
           (SELECT COUNT(*) FROM participants WHERE tournament_id = t.id) as joined_count
    FROM tournaments t 
    ORDER BY t.id DESC
")->fetchAll();
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<!-- Create Tournament Form -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 mb-6 shadow-xl">
    <h3 class="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center space-x-1.5">
        <i class="fa-solid fa-circle-plus"></i>
        <span>Create Tournament</span>
    </h3>
    <form method="POST" action="tournament.php" class="space-y-3">
        <input type="hidden" name="action" value="add_tournament">
        
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Title</label>
            <input type="text" name="title" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="Weekend Solo Battle Royale">
        </div>

        <div class="grid grid-cols-2 gap-2">
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Game Name</label>
                <input type="text" name="game_name" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="BGMI / Free Fire">
            </div>
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Match Time</label>
                <input type="datetime-local" name="match_time" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
            </div>
        </div>

        <!-- Numbers Grid -->
        <div class="grid grid-cols-2 gap-2">
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Entry Fee (₹)</label>
                <input type="number" name="entry_fee" step="0.01" min="0" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="50">
            </div>
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Prize Pool (₹)</label>
                <input type="number" name="prize_pool" step="0.01" min="0" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="400">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-2">
            <div>
                <label class="block text-[11px] text-slate-400 mb-1">Commission %</label>
                <input type="number" name="commission_percentage" step="0.1" min="0" value="20" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" placeholder="20">
            </div>
            <div>
                <label class="block text-[11px] text-amber-400 font-bold mb-1">Player Maximum</label>
                <input type="number" name="max_players" min="2" max="1000" value="100" required class="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-bold" placeholder="100">
            </div>
        </div>

        <!-- MATCH RULES BOX -->
        <div>
            <label class="block text-[11px] text-amber-400 font-bold mb-1 flex items-center space-x-1">
                <i class="fa-solid fa-scroll text-[10px]"></i>
                <span>Match Rules & Instructions</span>
            </label>
            <textarea 
                name="match_rules" 
                rows="3" 
                placeholder="1. Mobile only (No Emulators/iPads)&#10;2. Teaming is strictly prohibited&#10;3. Screenshot mandatory after match&#10;4. Room ID shared 15 mins before match" 
                class="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none"
            ></textarea>
            <p class="text-[10px] text-slate-500 mt-0.5">Players can read these rules before and after joining.</p>
        </div>

        <!-- Publish Button -->
        <button type="submit" class="w-full mt-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all">
            Publish Tournament
        </button>
    </form>
</div>

<!-- Tournaments List -->
<h3 class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">All Tournaments (<?= count($tournaments) ?>)</h3>
<?php if (empty($tournaments)): ?>
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
        No tournaments found.
    </div>
<?php else: ?>
    <div class="space-y-3">
        <?php foreach ($tournaments as $t): ?>
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow">
                <div class="flex items-center justify-between mb-1">
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-indigo-400 uppercase"><?= htmlspecialchars($t['game_name']) ?></span>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded <?= ($t['status'] === 'Completed') ? 'bg-slate-800 text-slate-400' : 'bg-emerald-500/10 text-emerald-400' ?>">
                        <?= $t['status'] ?>
                    </span>
                </div>
                <h4 class="text-xs font-bold text-white"><?= htmlspecialchars($t['title']) ?></h4>
                <div class="flex items-center justify-between text-[11px] text-slate-400 my-2">
                    <span>Entry: <strong class="text-white"><?= formatINR($t['entry_fee']) ?></strong></span>
                    <span>Pool: <strong class="text-emerald-400"><?= formatINR($t['prize_pool']) ?></strong></span>
                    <span class="text-amber-300 font-bold"><?= $t['joined_count'] ?>/<?= $t['max_players'] ?? 100 ?> Players</span>
                </div>
                <div class="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
                    <a href="manage_tournament.php?id=<?= $t['id'] ?>" class="px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold rounded-lg hover:bg-amber-500/20">
                        Manage
                    </a>
                    <a href="tournament.php?action=delete&id=<?= $t['id'] ?>" onclick="return confirm('Delete tournament #<?= $t['id'] ?>?');" class="px-3 py-1 bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold rounded-lg hover:bg-red-500/20">
                        Delete
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>