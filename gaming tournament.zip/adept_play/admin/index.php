<?php
// adept_play/admin/index.php
require_once __DIR__ . '/common/header.php';

// Quick Stats Calculation
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalTournaments = $pdo->query("SELECT COUNT(*) FROM tournaments")->fetchColumn();

// Total Prize Distributed (From Completed Tournaments)
$totalPrizeDistributed = $pdo->query("SELECT COALESCE(SUM(prize_pool), 0) FROM tournaments WHERE status = 'Completed'")->fetchColumn();

// Total Commission/Revenue Earned:
// Based on completed tournaments: (entry_fee * participants) - prize_pool OR commission formula
$totalCollected = $pdo->query("
    SELECT COALESCE(SUM(t.entry_fee), 0)
    FROM participants p
    JOIN tournaments t ON p.tournament_id = t.id
    WHERE t.status = 'Completed'
")->fetchColumn();
$totalRevenue = max(0, $totalCollected - $totalPrizeDistributed);
?>

<div class="mb-4">
    <h2 class="text-lg font-black text-white">System Overview</h2>
    <p class="text-xs text-slate-400">Real-time platform statistics</p>
</div>

<!-- 4 Small Tailwind Grid Cards -->
<div class="grid grid-cols-2 gap-3 mb-6">
    <!-- Total Users -->
    <div class="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm">
        <div class="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-sm mb-2">
            <i class="fa-solid fa-users"></i>
        </div>
        <span class="text-[11px] text-slate-400 font-medium">Total Users</span>
        <h4 class="text-xl font-black text-white mt-0.5"><?= number_format($totalUsers) ?></h4>
    </div>

    <!-- Total Tournaments -->
    <div class="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm">
        <div class="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center text-sm mb-2">
            <i class="fa-solid fa-trophy"></i>
        </div>
        <span class="text-[11px] text-slate-400 font-medium">Tournaments</span>
        <h4 class="text-xl font-black text-white mt-0.5"><?= number_format($totalTournaments) ?></h4>
    </div>

    <!-- Prize Distributed -->
    <div class="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm">
        <div class="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-sm mb-2">
            <i class="fa-solid fa-hand-holding-dollar"></i>
        </div>
        <span class="text-[11px] text-slate-400 font-medium">Prize Given</span>
        <h4 class="text-base font-black text-emerald-400 mt-0.5"><?= formatINR($totalPrizeDistributed) ?></h4>
    </div>

    <!-- Total Revenue -->
    <div class="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm">
        <div class="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center text-sm mb-2">
            <i class="fa-solid fa-sack-dollar"></i>
        </div>
        <span class="text-[11px] text-slate-400 font-medium">Net Revenue</span>
        <h4 class="text-base font-black text-purple-400 mt-0.5"><?= formatINR($totalRevenue) ?></h4>
    </div>
</div>

<!-- Quick Action -->
<a href="tournament.php" class="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs uppercase tracking-wider rounded-2xl flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/10 active:scale-95 transition-all mb-6">
    <i class="fa-solid fa-circle-plus text-sm"></i>
    <span>Create New Tournament</span>
</a>

<!-- Quick Recent Tournaments Activity -->
<h3 class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">Live & Upcoming Matches</h3>
<?php
$recentT = $pdo->query("SELECT * FROM tournaments WHERE status != 'Completed' ORDER BY match_time ASC LIMIT 5")->fetchAll();
?>
<?php if (empty($recentT)): ?>
    <div class="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-6 text-center">
        <p class="text-xs text-slate-500">No active matches. Click "Create New Tournament" above.</p>
    </div>
<?php else: ?>
    <div class="space-y-3">
        <?php foreach ($recentT as $rt): ?>
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
                <div>
                    <span class="text-[10px] text-indigo-400 font-bold uppercase"><?= htmlspecialchars($rt['game_name']) ?></span>
                    <h5 class="text-xs font-bold text-white"><?= htmlspecialchars($rt['title']) ?></h5>
                    <p class="text-[10px] text-slate-400"><?= date('d M, h:i A', strtotime($rt['match_time'])) ?></p>
                </div>
                <a href="manage_tournament.php?id=<?= $rt['id'] ?>" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-[11px] rounded-xl border border-slate-700">
                    Manage &rarr;
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>