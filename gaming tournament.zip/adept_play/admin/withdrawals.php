<?php
// adept_play/admin/withdrawals.php
require_once __DIR__ . '/common/header.php';

$message = '';
$messageType = '';

// Handle Approve / Reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdrawal_id'], $_POST['action_type'])) {
    $wId = (int)$_POST['withdrawal_id'];
    $actionType = $_POST['action_type'];

    $stmtW = $pdo->prepare("SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
    $stmtW->execute([$wId]);
    $with = $stmtW->fetch();

    if (!$with) {
        $message = "Withdrawal request not found.";
        $messageType = 'error';
    } elseif ($with['status'] !== 'Pending') {
        $message = "This request has already been processed as " . $with['status'] . ".";
        $messageType = 'error';
    } else {
        if ($actionType === 'approve') {
            // Balance was placed on hold/debited when user requested withdrawal
            $upd = $pdo->prepare("UPDATE withdrawals SET status = 'Completed' WHERE id = ?");
            $upd->execute([$wId]);

            // Finalize debit entry in transactions
            $desc = "Withdrawal Processed to UPI: " . $with['upi_id'];
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)");
            $tx->execute([$with['user_id'], $with['amount'], $desc]);

            $message = "Withdrawal #$wId marked as Completed!";
            $messageType = 'success';
        } elseif ($actionType === 'reject') {
            $pdo->beginTransaction();
            // 1. Mark as Rejected
            $upd = $pdo->prepare("UPDATE withdrawals SET status = 'Rejected' WHERE id = ?");
            $upd->execute([$wId]);

            // 2. Refund the held amount back to user's wallet
            $ref = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
            $ref->execute([$with['amount'], $with['user_id']]);

            // 3. Record refund transaction
            $desc = "Refund: Withdrawal Request #$wId Rejected";
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)");
            $tx->execute([$with['user_id'], $with['amount'], $desc]);

            $pdo->commit();
            $message = "Withdrawal #$wId rejected. Funds refunded to user's wallet.";
            $messageType = 'success';
        }
    }
}

// Fetch all requests (Pending first)
$withdrawals = $pdo->query("
    SELECT w.*, u.username 
    FROM withdrawals w 
    JOIN users u ON w.user_id = u.id 
    ORDER BY CASE WHEN w.status = 'Pending' THEN 1 ELSE 2 END, w.id DESC
")->fetchAll();
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
    <h2 class="text-base font-black text-white">Withdrawal Requests</h2>
    <span class="text-xs text-slate-400"><?= count($withdrawals) ?> total</span>
</div>

<?php if (empty($withdrawals)): ?>
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-500">
        No withdrawal requests found.
    </div>
<?php else: ?>
    <div class="space-y-3">
        <?php foreach ($withdrawals as $w): ?>
            <div class="bg-slate-900 border <?= ($w['status'] === 'Pending') ? 'border-indigo-500/40 bg-indigo-500/5' : 'border-slate-800' ?> rounded-2xl p-4 shadow-sm">
                <div class="flex items-start justify-between">
                    <div>
                        <span class="text-xs font-bold text-white"><?= htmlspecialchars($w['username']) ?></span>
                        <div class="text-[11px] font-mono text-amber-300 mt-0.5">
                            Pay to UPI: <strong class="text-white select-all"><?= htmlspecialchars($w['upi_id']) ?></strong>
                        </div>
                        <span class="text-[10px] text-slate-500"><?= date('d M Y, h:i A', strtotime($w['created_at'])) ?></span>
                    </div>
                    <div class="text-right">
                        <span class="text-sm font-black text-white"><?= formatINR($w['amount']) ?></span>
                        <div>
                            <span class="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full <?= ($w['status'] === 'Pending') ? 'bg-amber-500/20 text-amber-300' : (($w['status'] === 'Completed') ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400') ?>">
                                <?= $w['status'] ?>
                            </span>
                        </div>
                    </div>
                </div>

                <?php if ($w['status'] === 'Pending'): ?>
                    <p class="text-[10px] text-slate-400 mt-2 bg-slate-950 p-2 rounded-xl">
                        💡 Manually send <strong><?= formatINR($w['amount']) ?></strong> to UPI <code><?= htmlspecialchars($w['upi_id']) ?></code> using your payment app, then click Approve.
                    </p>
                    <div class="grid grid-cols-2 gap-2 mt-3 pt-2 border-t border-slate-800">
                        <form method="POST" action="withdrawals.php">
                            <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                            <input type="hidden" name="action_type" value="approve">
                            <button type="submit" onclick="return confirm('Confirm you sent <?= formatINR($w['amount']) ?> to <?= htmlspecialchars($w['upi_id']) ?>?');" class="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                                <i class="fa-solid fa-check mr-1"></i> Sent & Approve
                            </button>
                        </form>
                        <form method="POST" action="withdrawals.php">
                            <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                            <input type="hidden" name="action_type" value="reject">
                            <button type="submit" onclick="return confirm('Reject and refund <?= formatINR($w['amount']) ?> to user?');" class="w-full py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow transition-colors">
                                <i class="fa-solid fa-xmark mr-1"></i> Reject & Refund
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/common/bottom.php'; ?>