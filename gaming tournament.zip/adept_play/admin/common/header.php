<?php
// admin/common/header.php
require_once __DIR__ . '/../../common/config.php';
checkAdminAuth();

// Ensure all tables exist
$pdo->exec("CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(50) NOT NULL UNIQUE,
    `setting_value` TEXT NULL
) ENGINE=InnoDB;");

$pdo->exec("CREATE TABLE IF NOT EXISTS `deposits` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `transaction_id` VARCHAR(100) NOT NULL,
    `status` ENUM('Pending', 'Completed', 'Rejected') NOT NULL DEFAULT 'Pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;");

$pdo->exec("CREATE TABLE IF NOT EXISTS `withdrawals` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `upi_id` VARCHAR(255) NOT NULL,
    `status` ENUM('Pending', 'Completed', 'Rejected') NOT NULL DEFAULT 'Pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;");

$globalAlertMsg = '';
$globalAlertType = '';
$adminId = $_SESSION['admin_id'] ?? 1;

// 1. Handle Admin Change Password Form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_admin_password') {
    $currentPass = $_POST['current_password'] ?? '';
    $newPass     = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_password'] ?? '';

    if (empty($currentPass) || empty($newPass) || empty($confirmPass)) {
        $globalAlertMsg = "❌ Please fill in all password fields.";
        $globalAlertType = 'error';
    } elseif ($newPass !== $confirmPass) {
        $globalAlertMsg = "❌ New passwords do not match.";
        $globalAlertType = 'error';
    } elseif (strlen($newPass) < 6) {
        $globalAlertMsg = "❌ New password must be at least 6 characters long.";
        $globalAlertType = 'error';
    } else {
        $stmtA = $pdo->prepare("SELECT password FROM admin WHERE id = ?");
        $stmtA->execute([$adminId]);
        $storedHash = $stmtA->fetchColumn();

        if (!password_verify($currentPass, $storedHash)) {
            $globalAlertMsg = "❌ Current admin password is incorrect.";
            $globalAlertType = 'error';
        } else {
            $newHash = password_hash($newPass, PASSWORD_BCRYPT);
            $updA = $pdo->prepare("UPDATE admin SET password = ? WHERE id = ?");
            $updA->execute([$newHash, $adminId]);

            $globalAlertMsg = "✅ Admin password updated successfully!";
            $globalAlertType = 'success';
        }
    }
}

// 2. Handle Deposit Approval / Rejection from Modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'manage_deposit') {
    $depositId = (int)($_POST['deposit_id'] ?? 0);
    $actionType = $_POST['action_type'] ?? '';

    $stmtD = $pdo->prepare("SELECT d.*, u.username FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.id = ?");
    $stmtD->execute([$depositId]);
    $dep = $stmtD->fetch();

    if ($dep && $dep['status'] === 'Pending') {
        if ($actionType === 'approve') {
            $pdo->beginTransaction();
            $upd = $pdo->prepare("UPDATE deposits SET status = 'Completed' WHERE id = ?");
            $upd->execute([$depositId]);

            $updUser = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
            $updUser->execute([$dep['amount'], $dep['user_id']]);

            $desc = "Deposit Approved (Ref: " . $dep['transaction_id'] . ")";
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)");
            $tx->execute([$dep['user_id'], $dep['amount'], $desc]);
            $pdo->commit();

            $globalAlertMsg = "✅ Deposit of " . formatINR($dep['amount']) . " for " . htmlspecialchars($dep['username']) . " Approved!";
            $globalAlertType = 'success';
        } elseif ($actionType === 'reject') {
            $upd = $pdo->prepare("UPDATE deposits SET status = 'Rejected' WHERE id = ?");
            $upd->execute([$depositId]);
            $globalAlertMsg = "❌ Deposit request #$depositId was Rejected.";
            $globalAlertType = 'error';
        }
    }
}

// 3. Handle Withdrawal Approval / Rejection from Modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'manage_withdrawal') {
    $wId = (int)($_POST['withdrawal_id'] ?? 0);
    $actionType = $_POST['action_type'] ?? '';

    $stmtW = $pdo->prepare("SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
    $stmtW->execute([$wId]);
    $with = $stmtW->fetch();

    if ($with && $with['status'] === 'Pending') {
        if ($actionType === 'approve') {
            $upd = $pdo->prepare("UPDATE withdrawals SET status = 'Completed' WHERE id = ?");
            $upd->execute([$wId]);

            $desc = "Withdrawal Processed to UPI: " . $with['upi_id'];
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)");
            $tx->execute([$with['user_id'], $with['amount'], $desc]);

            $globalAlertMsg = "✅ Withdrawal of " . formatINR($with['amount']) . " marked Sent & Approved!";
            $globalAlertType = 'success';
        } elseif ($actionType === 'reject') {
            $pdo->beginTransaction();
            $upd = $pdo->prepare("UPDATE withdrawals SET status = 'Rejected' WHERE id = ?");
            $upd->execute([$wId]);

            $ref = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
            $ref->execute([$with['amount'], $with['user_id']]);

            $desc = "Refund: Withdrawal Request #$wId Rejected";
            $tx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)");
            $tx->execute([$with['user_id'], $with['amount'], $desc]);
            $pdo->commit();

            $globalAlertMsg = "❌ Withdrawal #$wId Rejected. " . formatINR($with['amount']) . " refunded to user.";
            $globalAlertType = 'error';
        }
    }
}

// 4. Handle QR & UPI Settings Modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_admin_qr_upi') {
    $upiId = trim($_POST['admin_upi_id'] ?? '');
    if (!empty($upiId)) {
        $updUpi = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('admin_upi_id', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $updUpi->execute([$upiId, $upiId]);
    }
    if (isset($_FILES['qr_code']) && $_FILES['qr_code']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../../uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $ext = strtolower(pathinfo($_FILES['qr_code']['name'], PATHINFO_EXTENSION));
        $newFileName = 'admin_qr_' . time() . '.' . $ext;
        if (move_uploaded_file($_FILES['qr_code']['tmp_name'], $uploadDir . $newFileName)) {
            $savedPath = 'uploads/' . $newFileName;
            $updQr = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('admin_qr_code', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $updQr->execute([$savedPath, $savedPath]);
        }
    }
    $globalAlertMsg = "✅ Payment Settings updated!";
    $globalAlertType = 'success';
}

// Fetch Pending Requests
$pendingDeposits = $pdo->query("SELECT d.*, u.username FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.status = 'Pending' ORDER BY d.id DESC")->fetchAll();
$pendingWithdrawals = $pdo->query("SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.status = 'Pending' ORDER BY w.id DESC")->fetchAll();

$stmtSettings = $pdo->query("SELECT setting_key, setting_value FROM settings");
$settingsMap = $stmtSettings->fetchAll(PDO::FETCH_KEY_PAIR);
$adminUpiVal = $settingsMap['admin_upi_id'] ?? '';
$adminQrVal  = $settingsMap['admin_qr_code'] ?? '';
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Tournament - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { -webkit-tap-highlight-color: transparent; user-select: none; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 flex justify-center min-h-screen antialiased">
    <div class="w-full max-w-md bg-slate-900 border-x border-slate-800 min-h-screen flex flex-col pb-24 shadow-2xl relative">
        
        <header class="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <span class="px-2 py-0.5 bg-amber-500 text-slate-950 font-black text-[10px] rounded uppercase tracking-wider">ADMIN</span>
                <span class="text-sm font-black text-white">Console</span>
            </div>
            <a href="login.php?action=logout" class="text-xs text-red-400 hover:text-red-300 font-bold transition-colors">
                <i class="fa-solid fa-power-off mr-1"></i> Logout
            </a>
        </header>

        <main class="flex-1 px-4 py-4">

        <?php if (!empty($globalAlertMsg)): ?>
            <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($globalAlertType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
                <i class="fa-solid <?= ($globalAlertType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                <span><?= htmlspecialchars($globalAlertMsg) ?></span>
            </div>
        <?php endif; ?>