</main>

        <!-- ================= 1. DEPOSIT REQUESTS POPUP MODAL ================= -->
        <div id="admin-deposits-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
            <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative max-h-[85vh] flex flex-col">
                <button type="button" onclick="closeModal('admin-deposits-modal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>

                <div class="flex items-center space-x-2 mb-1">
                    <div class="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-sm">
                        <i class="fa-solid fa-arrow-down-long"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-white">Deposit Requests</h3>
                        <p class="text-[10px] text-slate-400"><?= count($pendingDeposits) ?> pending approval</p>
                    </div>
                </div>

                <div class="overflow-y-auto space-y-3 mt-3 pr-1 flex-1">
                    <?php if (empty($pendingDeposits)): ?>
                        <div class="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-2xl">
                            <i class="fa-solid fa-check-circle text-2xl text-emerald-500/40 mb-1"></i>
                            <p>No pending deposit requests.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pendingDeposits as $d): ?>
                            <div class="bg-slate-950 border border-slate-800 rounded-2xl p-3 shadow">
                                <div class="flex justify-between items-start mb-1">
                                    <span class="text-xs font-bold text-white"><?= htmlspecialchars($d['username']) ?></span>
                                    <span class="text-xs font-black text-emerald-400"><?= formatINR($d['amount']) ?></span>
                                </div>
                                <div class="text-[11px] font-mono text-amber-300 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 my-1.5 select-all">
                                    UTR: <?= htmlspecialchars($d['transaction_id']) ?>
                                </div>
                                <div class="text-[9px] text-slate-500 mb-2">
                                    <?= date('d M, h:i A', strtotime($d['created_at'])) ?>
                                </div>
                                <div class="grid grid-cols-2 gap-2">
                                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                                        <input type="hidden" name="action" value="manage_deposit">
                                        <input type="hidden" name="action_type" value="approve">
                                        <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
                                        <button type="submit" onclick="return confirm('Approve payment of <?= formatINR($d['amount']) ?>?');" class="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] rounded-xl transition-all">
                                            ✓ Approve
                                        </button>
                                    </form>
                                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                                        <input type="hidden" name="action" value="manage_deposit">
                                        <input type="hidden" name="action_type" value="reject">
                                        <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
                                        <button type="submit" onclick="return confirm('Reject this request?');" class="w-full py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] rounded-xl transition-all">
                                            ✕ Reject
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ================= 2. WITHDRAWAL REQUESTS POPUP MODAL ================= -->
        <div id="admin-withdrawals-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
            <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative max-h-[85vh] flex flex-col">
                <button type="button" onclick="closeModal('admin-withdrawals-modal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>

                <div class="flex items-center space-x-2 mb-1">
                    <div class="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-sm">
                        <i class="fa-solid fa-arrow-up-long"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-white">Withdrawal Requests</h3>
                        <p class="text-[10px] text-slate-400"><?= count($pendingWithdrawals) ?> pending payouts</p>
                    </div>
                </div>

                <div class="overflow-y-auto space-y-3 mt-3 pr-1 flex-1">
                    <?php if (empty($pendingWithdrawals)): ?>
                        <div class="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-2xl">
                            <i class="fa-solid fa-circle-check text-2xl text-indigo-500/40 mb-1"></i>
                            <p>No pending withdrawal requests.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pendingWithdrawals as $w): ?>
                            <div class="bg-slate-950 border border-slate-800 rounded-2xl p-3 shadow">
                                <div class="flex justify-between items-start mb-1">
                                    <span class="text-xs font-bold text-white"><?= htmlspecialchars($w['username']) ?></span>
                                    <span class="text-xs font-black text-amber-400"><?= formatINR($w['amount']) ?></span>
                                </div>
                                <div class="text-[11px] font-mono text-white bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 my-1 select-all">
                                    UPI: <strong class="text-amber-300"><?= htmlspecialchars($w['upi_id']) ?></strong>
                                </div>
                                <p class="text-[10px] text-slate-400 mb-2">
                                    Send <?= formatINR($w['amount']) ?> in your UPI app, then click Sent.
                                </p>
                                <div class="grid grid-cols-2 gap-2">
                                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                                        <input type="hidden" name="action" value="manage_withdrawal">
                                        <input type="hidden" name="action_type" value="approve">
                                        <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                                        <button type="submit" onclick="return confirm('Confirm payment of <?= formatINR($w['amount']) ?> sent to <?= htmlspecialchars($w['upi_id']) ?>?');" class="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] rounded-xl transition-all">
                                            ✓ Sent & Done
                                        </button>
                                    </form>
                                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                                        <input type="hidden" name="action" value="manage_withdrawal">
                                        <input type="hidden" name="action_type" value="reject">
                                        <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                                        <button type="submit" onclick="return confirm('Reject and refund balance to user?');" class="w-full py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] rounded-xl transition-all">
                                            ✕ Reject & Refund
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ================= 3. SETTINGS & PASSWORD POPUP MODAL ================= -->
        <div id="admin-settings-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
            <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
                <!-- Close Button -->
                <button type="button" onclick="closeModal('admin-settings-modal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>

                <h3 class="text-sm font-black text-white mb-3 flex items-center space-x-1.5">
                    <i class="fa-solid fa-gear text-amber-400"></i>
                    <span>Admin Settings</span>
                </h3>

                <!-- Tab Buttons -->
                <div class="flex bg-slate-950 p-1 rounded-xl mb-4 border border-slate-800">
                    <button type="button" id="tab-btn-qr" onclick="switchAdminTab('qr')" class="flex-1 py-1.5 text-xs font-bold rounded-lg transition-all bg-amber-500 text-slate-950 shadow">
                        UPI & QR
                    </button>
                    <button type="button" id="tab-btn-pass" onclick="switchAdminTab('pass')" class="flex-1 py-1.5 text-xs font-bold rounded-lg transition-all text-slate-400 hover:text-white">
                        Change Password
                    </button>
                </div>

                <!-- TAB 1: UPI & QR -->
                <div id="tab-content-qr">
                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" enctype="multipart/form-data" class="space-y-3">
                        <input type="hidden" name="action" value="save_admin_qr_upi">
                        <div>
                            <label class="block text-[11px] font-bold text-slate-300 mb-1">Admin UPI ID</label>
                            <input type="text" name="admin_upi_id" value="<?= htmlspecialchars($adminUpiVal ?? '') ?>" required placeholder="e.g. 9876543210@paytm" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-slate-300 mb-1">QR Code Image</label>
                            <?php if (!empty($adminQrVal) && file_exists(__DIR__ . '/../../' . $adminQrVal)): ?>
                                <img src="../<?= htmlspecialchars($adminQrVal) ?>" class="w-16 h-16 object-contain bg-white rounded-lg p-1 mb-1.5">
                            <?php endif; ?>
                            <input type="file" name="qr_code" accept="image/*" class="w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:bg-slate-800 file:text-white cursor-pointer">
                        </div>
                        <button type="submit" class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase rounded-xl transition-all">
                            Save QR & UPI
                        </button>
                    </form>
                </div>

                <!-- TAB 2: Change Password -->
                <div id="tab-content-pass" class="hidden">
                    <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" class="space-y-3">
                        <input type="hidden" name="action" value="change_admin_password">
                        <div>
                            <label class="block text-[11px] font-bold text-slate-300 mb-1">Current Password</label>
                            <input type="password" name="current_password" required placeholder="••••••••" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-slate-300 mb-1">New Password (min 6 chars)</label>
                            <input type="password" name="new_password" minlength="6" required placeholder="••••••••" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-slate-300 mb-1">Confirm New Password</label>
                            <input type="password" name="confirm_password" minlength="6" required placeholder="••••••••" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                        </div>
                        <button type="submit" class="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all">
                            Update Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ================= BOTTOM NAVIGATION BAR ================= -->
        <?php $admPage = basename($_SERVER['PHP_SELF']); ?>
        <nav class="fixed bottom-0 left-0 right-0 z-40 flex justify-center pointer-events-none">
            <div class="w-full max-w-md bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-1 py-2 flex items-center justify-around pointer-events-auto shadow-2xl">
                <!-- Home -->
                <a href="index.php" class="flex flex-col items-center py-1 px-2 <?= ($admPage === 'index.php') ? 'text-amber-400 font-bold' : 'text-slate-400' ?>">
                    <i class="fa-solid fa-chart-pie text-sm mb-0.5"></i>
                    <span class="text-[9px]">Home</span>
                </a>

                <!-- Deposit POPUP Trigger -->
                <button type="button" onclick="openModal('admin-deposits-modal')" class="flex flex-col items-center py-1 px-2 text-slate-400 hover:text-emerald-400 relative focus:outline-none">
                    <?php if (!empty($pendingDeposits)): ?>
                        <span class="absolute top-0 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                    <?php endif; ?>
                    <i class="fa-solid fa-arrow-down-long text-sm mb-0.5"></i>
                    <span class="text-[9px]">Deposits</span>
                </button>

                <!-- Withdraw POPUP Trigger -->
                <button type="button" onclick="openModal('admin-withdrawals-modal')" class="flex flex-col items-center py-1 px-2 text-slate-400 hover:text-indigo-400 relative focus:outline-none">
                    <?php if (!empty($pendingWithdrawals)): ?>
                        <span class="absolute top-0 right-1 w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                    <?php endif; ?>
                    <i class="fa-solid fa-arrow-up-long text-sm mb-0.5"></i>
                    <span class="text-[9px]">Withdraw</span>
                </button>

                <!-- Matches -->
                <a href="tournament.php" class="flex flex-col items-center py-1 px-2 <?= ($admPage === 'tournament.php') ? 'text-amber-400 font-bold' : 'text-slate-400' ?>">
                    <i class="fa-solid fa-gamepad text-sm mb-0.5"></i>
                    <span class="text-[9px]">Matches</span>
                </a>

                <!-- Users -->
                <a href="user.php" class="flex flex-col items-center py-1 px-2 <?= ($admPage === 'user.php') ? 'text-amber-400 font-bold' : 'text-slate-400' ?>">
                    <i class="fa-solid fa-users text-sm mb-0.5"></i>
                    <span class="text-[9px]">Users</span>
                </a>

                <!-- Settings POPUP Trigger -->
                <button type="button" onclick="openModal('admin-settings-modal')" class="flex flex-col items-center py-1 px-2 text-slate-400 hover:text-amber-400 focus:outline-none">
                    <i class="fa-solid fa-gear text-sm mb-0.5"></i>
                    <span class="text-[9px]">Settings</span>
                </button>
            </div>
        </nav>
    </div>

    <!-- Modal Helper Script -->
    <script>
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }
        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }

        function switchAdminTab(tab) {
            const tabQr = document.getElementById('tab-content-qr');
            const tabPass = document.getElementById('tab-content-pass');
            const btnQr = document.getElementById('tab-btn-qr');
            const btnPass = document.getElementById('tab-btn-pass');

            if (tab === 'qr') {
                tabQr.classList.remove('hidden');
                tabPass.classList.add('hidden');
                btnQr.className = 'flex-1 py-1.5 text-xs font-bold rounded-lg transition-all bg-amber-500 text-slate-950 shadow';
                btnPass.className = 'flex-1 py-1.5 text-xs font-bold rounded-lg transition-all text-slate-400 hover:text-white';
            } else {
                tabPass.classList.remove('hidden');
                tabQr.classList.add('hidden');
                btnPass.className = 'flex-1 py-1.5 text-xs font-bold rounded-lg transition-all bg-amber-500 text-slate-950 shadow';
                btnQr.className = 'flex-1 py-1.5 text-xs font-bold rounded-lg transition-all text-slate-400 hover:text-white';
            }
        }

        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('selectstart', e => e.preventDefault());
    </script>
</body>
</html>