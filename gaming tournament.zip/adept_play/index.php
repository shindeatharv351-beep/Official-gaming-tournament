<?php
// index.php
require_once __DIR__ . '/common/config.php';
checkUserAuth();

// Safely ensure columns exist
$chkCols = $pdo->query("SHOW COLUMNS FROM `participants` LIKE 'in_game_name'")->fetchAll();
if (empty($chkCols)) {
    $pdo->exec("ALTER TABLE `participants` ADD COLUMN `in_game_name` VARCHAR(100) NULL AFTER `tournament_id`;");
    $pdo->exec("ALTER TABLE `participants` ADD COLUMN `in_game_id` VARCHAR(100) NULL AFTER `in_game_name`;");
}
$chkSlot = $pdo->query("SHOW COLUMNS FROM `participants` LIKE 'slot_no'")->fetchAll();
if (empty($chkSlot)) {
    $pdo->exec("ALTER TABLE `participants` ADD COLUMN `slot_no` INT NOT NULL DEFAULT 1 AFTER `tournament_id`;");
}

$userId = $_SESSION['user_id'];
$alertMessage = '';
$alertType = '';

// Handle Joining Process with Slot Assignment (1 to 100)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'join_tournament') {
    $tournamentId = (int)($_POST['tournament_id'] ?? 0);
    $inGameName   = trim($_POST['in_game_name'] ?? '');
    $inGameId     = trim($_POST['in_game_id'] ?? '');

    if (empty($inGameName) || empty($inGameId)) {
        $alertType = 'error';
        $alertMessage = "Please enter both Player Nickname and Game ID/UID.";
    } else {
        $stmtT = $pdo->prepare("SELECT * FROM tournaments WHERE id = ? AND status = 'Upcoming'");
        $stmtT->execute([$tournamentId]);
        $tournament = $stmtT->fetch();

        if (!$tournament) {
            $alertType = 'error';
            $alertMessage = "Tournament is not open for joining or does not exist.";
        } else {
            $stmtP = $pdo->prepare("SELECT id FROM participants WHERE user_id = ? AND tournament_id = ?");
            $stmtP->execute([$userId, $tournamentId]);
            if ($stmtP->fetch()) {
                $alertType = 'error';
                $alertMessage = "You have already joined this tournament!";
            } else {
                $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM participants WHERE tournament_id = ?");
                $stmtCount->execute([$tournamentId]);
                $currentCount = (int)$stmtCount->fetchColumn();
                $maxLimit = (int)($tournament['max_players'] ?? 100);

                if ($currentCount >= $maxLimit) {
                    $alertType = 'error';
                    $alertMessage = "Sorry, this tournament has reached its maximum limit ($maxLimit players max)!";
                } else {
                    $stmtU = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE");
                    $pdo->beginTransaction();
                    $stmtU->execute([$userId]);
                    $userData = $stmtU->fetch();

                    if ($userData['wallet_balance'] < $tournament['entry_fee']) {
                        $pdo->rollBack();
                        $alertType = 'error';
                        $alertMessage = "Insufficient balance! Please add money to your wallet.";
                    } else {
                        // Assign Slot Number (1 to 100)
                        $assignedSlot = $currentCount + 1;

                        $newBal = $userData['wallet_balance'] - $tournament['entry_fee'];
                        $updU = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
                        $updU->execute([$newBal, $userId]);

                        $addP = $pdo->prepare("INSERT INTO participants (user_id, tournament_id, slot_no, in_game_name, in_game_id) VALUES (?, ?, ?, ?, ?)");
                        $addP->execute([$userId, $tournamentId, $assignedSlot, $inGameName, $inGameId]);

                        $desc = "Joined #" . $tournament['id'] . " (" . $tournament['title'] . ") - Slot #$assignedSlot";
                        $addTx = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)");
                        $addTx->execute([$userId, $tournament['entry_fee'], $desc]);

                        $pdo->commit();
                        $alertType = 'success';
                        $alertMessage = "Joined successfully! You are assigned Slot #$assignedSlot.";
                    }
                }
            }
        }
    }
}

// Fetch Tournaments & Check if current user joined
$searchQuery = trim($_GET['search'] ?? '');
$sql = "
    SELECT t.*, 
           (SELECT COUNT(*) FROM participants WHERE tournament_id = t.id) as joined_count,
           (SELECT slot_no FROM participants WHERE tournament_id = t.id AND user_id = ? LIMIT 1) as my_slot_no
    FROM tournaments t
    WHERE t.status = 'Upcoming'
";
$params = [$userId];

if (!empty($searchQuery)) {
    $sql .= " AND (t.title LIKE ? OR t.game_name LIKE ?)";
    $params[] = "%$searchQuery%";
    $params[] = "%$searchQuery%";
}

$sql .= " ORDER BY t.match_time ASC";

$stmtTournaments = $pdo->prepare($sql);
$stmtTournaments->execute($params);
$tournaments = $stmtTournaments->fetchAll();

// Pre-fetch all participants for slot viewers
$allParticipantsQuery = $pdo->query("
    SELECT p.tournament_id, p.slot_no, p.in_game_name, u.username 
    FROM participants p 
    JOIN users u ON p.user_id = u.id 
    ORDER BY p.slot_no ASC
")->fetchAll();

$slotsByTournament = [];
foreach ($allParticipantsQuery as $row) {
    $slotsByTournament[$row['tournament_id']][] = $row;
}

require_once __DIR__ . '/common/header.php';
?>

<!-- Banner Alerts -->
<?php if (!empty($alertMessage)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($alertType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($alertType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?> text-sm"></i>
        <span><?= htmlspecialchars($alertMessage) ?></span>
    </div>
<?php endif; ?>

<!-- Hero Promotion Card -->
<div class="relative bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-4 mb-4 border border-indigo-700/40 overflow-hidden shadow-lg">
    <div class="relative z-10">
        <span class="bg-amber-500/20 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border border-amber-500/30">Official Battles</span>
        <h2 class="text-lg font-black text-white mt-1">Play Tournaments & Win Real Cash</h2>
        <p class="text-[11px] text-slate-300 mt-0.5">Rooms & passwords update 15 mins prior to match time.</p>
    </div>
    <div class="absolute -right-4 -bottom-4 text-indigo-950/40 text-8xl font-black pointer-events-none">
        <i class="fa-solid fa-trophy"></i>
    </div>
</div>

<!-- Search Bar -->
<div class="mb-4">
    <form method="GET" action="index.php" class="relative flex items-center">
        <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
            <i class="fa-solid fa-magnifying-glass text-xs"></i>
        </span>
        <input 
            type="text" 
            name="search" 
            id="tournament-search" 
            value="<?= htmlspecialchars($searchQuery) ?>" 
            placeholder="Search game, BGMI, Free Fire, title..." 
            autocomplete="off"
            class="w-full bg-slate-950 border border-slate-800 focus:border-amber-500/80 rounded-2xl pl-9 pr-20 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-colors shadow-inner"
        >
        <div class="absolute inset-y-0 right-1 flex items-center space-x-1 pr-1.5">
            <?php if (!empty($searchQuery)): ?>
                <a href="index.php" class="text-slate-500 hover:text-slate-300 p-1 text-xs">
                    <i class="fa-solid fa-circle-xmark"></i>
                </a>
            <?php endif; ?>
            <button type="submit" class="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] uppercase rounded-xl transition-all">
                Search
            </button>
        </div>
    </form>
</div>

<!-- Section Heading -->
<div class="flex items-center justify-between mb-3 px-1">
    <div class="flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
        <h3 class="text-sm font-bold text-slate-200 uppercase tracking-wider">Upcoming Matches</h3>
    </div>
    <span class="text-xs text-slate-400" id="match-counter"><?= count($tournaments) ?> available</span>
</div>

<!-- Tournaments List -->
<?php if (empty($tournaments)): ?>
    <div class="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-8 text-center my-6">
        <i class="fa-solid fa-gamepad text-3xl text-slate-600 mb-2"></i>
        <p class="text-xs text-slate-400">No upcoming matches at the moment.<br>Please check back soon!</p>
    </div>
<?php else: ?>
    <div class="space-y-4" id="tournaments-container">
        <?php foreach ($tournaments as $t): ?>
            <?php 
            $maxLimit = (int)($t['max_players'] ?? 100);
            $isFull = ($t['joined_count'] >= $maxLimit);
            $hasJoined = !empty($t['my_slot_no']);
            $joinedList = $slotsByTournament[$t['id']] ?? [];
            ?>
            <div 
                class="tournament-card bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md hover:border-slate-700 transition-all"
                data-title="<?= strtolower(htmlspecialchars($t['title'])) ?>"
                data-game="<?= strtolower(htmlspecialchars($t['game_name'])) ?>"
            >
                <div class="flex items-start justify-between mb-2">
                    <div>
                        <span class="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            <?= htmlspecialchars($t['game_name']) ?>
                        </span>
                        <h4 class="text-sm font-bold text-white mt-1"><?= htmlspecialchars($t['title']) ?></h4>
                    </div>
                    <!-- Front-Side Winning Amount Display -->
                    <div class="text-right">
                        <span class="text-[10px] text-slate-400 uppercase tracking-wide">Winning Prize</span>
                        <p class="text-base font-black text-emerald-400 leading-tight"><?= formatINR($t['prize_pool']) ?></p>
                    </div>
                </div>

                <!-- Match Details Grid -->
                <div class="grid grid-cols-2 gap-2 my-3 bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80 text-xs">
                    <div class="flex items-center space-x-2 text-slate-300">
                        <i class="fa-regular fa-clock text-amber-400 text-xs"></i>
                        <span><?= date('d M, h:i A', strtotime($t['match_time'])) ?></span>
                    </div>
                    <div class="flex items-center justify-end space-x-2 text-slate-300">
                        <i class="fa-solid fa-ticket text-indigo-400 text-xs"></i>
                        <span>Entry: <strong class="text-white"><?= formatINR($t['entry_fee']) ?></strong></span>
                    </div>
                </div>

                <!-- Interactive Slot Counter & View Slots Button -->
                <div class="flex items-center justify-between my-2 text-xs">
                    <span class="text-[11px] text-slate-400 flex items-center space-x-1">
                        <i class="fa-solid fa-users text-[10px] text-amber-400"></i>
                        <span class="font-bold text-white"><?= $t['joined_count'] ?></span> / <?= $maxLimit ?> Slots Filled
                    </span>
                    <button type="button" onclick="openSlotsModal(<?= $t['id'] ?>, '<?= htmlspecialchars(addslashes($t['title'])) ?>')" class="text-[11px] text-indigo-400 hover:text-indigo-300 font-bold flex items-center space-x-1 focus:outline-none">
                        <i class="fa-solid fa-list-ol text-[10px]"></i>
                        <span>View Slots (1 to <?= $maxLimit ?>)</span>
                    </button>
                </div>

                <!-- Rules Accordion (if exists) -->
                <?php if (!empty($t['match_rules'])): ?>
                    <div class="mb-3">
                        <button type="button" onclick="toggleRules(<?= $t['id'] ?>)" class="text-[11px] text-amber-400 hover:text-amber-300 font-bold flex items-center space-x-1 focus:outline-none">
                            <i class="fa-solid fa-scroll text-[10px]"></i>
                            <span>Match Rules</span>
                            <i class="fa-solid fa-chevron-down text-[9px] transition-transform duration-200" id="rule-icon-<?= $t['id'] ?>"></i>
                        </button>
                        <div id="rule-box-<?= $t['id'] ?>" class="hidden mt-1.5 bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-300 whitespace-pre-line leading-relaxed">
                            <?= htmlspecialchars($t['match_rules']) ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Bottom Action Row -->
                <div class="flex items-center justify-between mt-2 pt-2 border-t border-slate-800">
                    <?php if ($hasJoined): ?>
                        <div class="flex items-center space-x-2">
                            <span class="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold rounded-xl">
                                Your Slot: #<?= $t['my_slot_no'] ?>
                            </span>
                            <span class="text-xs text-emerald-400 font-bold flex items-center space-x-1">
                                <i class="fa-solid fa-check"></i>
                                <span>Joined</span>
                            </span>
                        </div>
                    <?php elseif ($isFull): ?>
                        <span class="px-4 py-2 bg-slate-800 text-slate-500 border border-slate-700 text-xs font-bold rounded-xl cursor-not-allowed">
                            Match Full
                        </span>
                    <?php else: ?>
                        <span class="text-[10px] text-slate-500">Fast filling, join now</span>
                        <button 
                            type="button" 
                            onclick="openJoinModal(<?= $t['id'] ?>, '<?= htmlspecialchars(addslashes($t['title'])) ?>', '<?= formatINR($t['entry_fee']) ?>')"
                            class="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 active:scale-95 text-slate-950 font-black text-xs rounded-xl shadow-md shadow-amber-500/20 transition-all uppercase tracking-wider"
                        >
                            Join Now
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Hidden JSON Data for Slots Modal -->
            <script>
                window['slots_data_<?= $t['id'] ?>'] = <?= json_encode($joinedList) ?>;
                window['max_slots_<?= $t['id'] ?>'] = <?= $maxLimit ?>;
            </script>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- ================= 1. VIEW SLOTS (1 TO 100) MODAL ================= -->
<div id="slots-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative max-h-[85vh] flex flex-col">
        <button type="button" onclick="closeSlotsModal()" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <div class="flex items-center space-x-2 mb-1">
            <div class="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-sm">
                <i class="fa-solid fa-users-viewfinder"></i>
            </div>
            <div>
                <h3 class="text-sm font-black text-white">Player Slots</h3>
                <p class="text-[10px] text-slate-400" id="slots-modal-title">Tournament Lineup</p>
            </div>
        </div>

        <div class="overflow-y-auto space-y-2 mt-3 pr-1 flex-1" id="slots-modal-list">
            <!-- Dynamic Slot Items 1 to 100 generated here -->
        </div>
    </div>
</div>

<!-- ================= 2. JOIN MATCH MODAL ================= -->
<div id="join-modal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl relative">
        <button type="button" onclick="closeJoinModal()" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1">
            <i class="fa-solid fa-xmark text-lg"></i>
        </button>

        <div class="flex items-center space-x-2 mb-1">
            <div class="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center text-sm">
                <i class="fa-solid fa-id-card"></i>
            </div>
            <div>
                <h3 class="text-sm font-black text-white">Player Registration</h3>
                <p class="text-[10px] text-slate-400" id="modal-tournament-title">Confirm match registration</p>
            </div>
        </div>

        <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 my-3 flex items-center justify-between text-xs">
            <span class="text-slate-400">Entry Fee:</span>
            <strong class="text-amber-400 font-black text-sm" id="modal-entry-fee">₹0.00</strong>
        </div>

        <form method="POST" action="index.php" class="space-y-3">
            <input type="hidden" name="action" value="join_tournament">
            <input type="hidden" name="tournament_id" id="modal-tournament-id" value="">

            <div>
                <label class="block text-[11px] font-bold text-slate-300 mb-1">In-Game Nickname (IGN)</label>
                <input type="text" name="in_game_name" required placeholder="e.g. ProSniper_99" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
            </div>

            <div>
                <label class="block text-[11px] font-bold text-slate-300 mb-1">Player Game ID / UID</label>
                <input type="text" name="in_game_id" required placeholder="e.g. 5189230192" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
            </div>

            <button type="submit" class="w-full mt-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all">
                Confirm & Pay Entry Fee
            </button>
        </form>
    </div>
</div>

<script>
// Open Slots 1 to 100 Viewer
function openSlotsModal(tournamentId, title) {
    document.getElementById('slots-modal-title').innerText = title;
    const listContainer = document.getElementById('slots-modal-list');
    listContainer.innerHTML = '';

    const joinedPlayers = window['slots_data_' + tournamentId] || [];
    const maxSlots = window['max_slots_' + tournamentId] || 100;

    // Create a map by slot number
    const slotMap = {};
    joinedPlayers.forEach(p => {
        slotMap[p.slot_no] = p;
    });

    // Render slots 1 to maxSlots
    for (let slot = 1; slot <= maxSlots; slot++) {
        const item = document.createElement('div');
        item.className = "flex items-center justify-between p-2.5 rounded-xl border text-xs " + 
            (slotMap[slot] ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-950/40 border-slate-800/40 text-slate-600");

        if (slotMap[slot]) {
            item.innerHTML = `
                <div class="flex items-center space-x-2">
                    <span class="px-2 py-0.5 rounded-lg bg-amber-500/10 text-amber-300 font-mono font-bold text-[10px]">Slot #${slot}</span>
                    <span class="font-bold text-white">${slotMap[slot].username}</span>
                </div>
                <span class="text-[11px] font-mono text-emerald-400">${slotMap[slot].in_game_name || 'Joined'}</span>
            `;
        } else {
            item.innerHTML = `
                <div class="flex items-center space-x-2">
                    <span class="px-2 py-0.5 rounded-lg bg-slate-900 text-slate-600 font-mono text-[10px]">Slot #${slot}</span>
                    <span class="text-slate-600 italic">Empty Slot</span>
                </div>
                <span class="text-[10px] text-slate-600">Open</span>
            `;
        }
        listContainer.appendChild(item);
    }

    document.getElementById('slots-modal').classList.remove('hidden');
}

function closeSlotsModal() {
    document.getElementById('slots-modal').classList.add('hidden');
}

function openJoinModal(id, title, fee) {
    document.getElementById('modal-tournament-id').value = id;
    document.getElementById('modal-tournament-title').innerText = title;
    document.getElementById('modal-entry-fee').innerText = fee;
    document.getElementById('join-modal').classList.remove('hidden');
}

function closeJoinModal() {
    document.getElementById('join-modal').classList.add('hidden');
}

function toggleRules(id) {
    const box = document.getElementById('rule-box-' + id);
    const icon = document.getElementById('rule-icon-' + id);
    if (box) {
        box.classList.toggle('hidden');
        if (icon) icon.classList.toggle('rotate-180');
    }
}
</script>

<?php require_once __DIR__ . '/common/bottom.php'; ?>