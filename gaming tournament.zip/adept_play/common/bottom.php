</main>
        <!-- Bottom Tab Navigation -->
        <?php
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        <nav class="fixed bottom-0 left-0 right-0 z-50 flex justify-center pointer-events-none">
            <div class="w-full max-w-md bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-3 py-2 flex items-center justify-around pointer-events-auto shadow-2xl">
                <!-- Home -->
                <a href="index.php" class="flex flex-col items-center py-1 px-3 transition-colors <?= ($currentPage === 'index.php') ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200' ?>">
                    <i class="fa-solid fa-fire text-lg mb-0.5"></i>
                    <span class="text-[10px] tracking-wide">Home</span>
                </a>
                <!-- My Tournaments -->
                <a href="my_tournaments.php" class="flex flex-col items-center py-1 px-3 transition-colors <?= ($currentPage === 'my_tournaments.php') ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200' ?>">
                    <i class="fa-solid fa-trophy text-lg mb-0.5"></i>
                    <span class="text-[10px] tracking-wide">Matches</span>
                </a>
                <!-- Wallet -->
                <a href="wallet.php" class="flex flex-col items-center py-1 px-3 transition-colors <?= ($currentPage === 'wallet.php') ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200' ?>">
                    <i class="fa-solid fa-wallet text-lg mb-0.5"></i>
                    <span class="text-[10px] tracking-wide">Wallet</span>
                </a>
                <!-- Profile -->
                <a href="profile.php" class="flex flex-col items-center py-1 px-3 transition-colors <?= ($currentPage === 'profile.php') ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200' ?>">
                    <i class="fa-solid fa-user-astronaut text-lg mb-0.5"></i>
                    <span class="text-[10px] tracking-wide">Profile</span>
                </a>
            </div>
        </nav>
    </div>

    <!-- Security & UX Lockdown Script -->
    <script>
        // 1. Disable Context Menu (Right Click / Long Press)
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // 2. Disable Text Dragging and Selection
        document.addEventListener('selectstart', function(e) {
            e.preventDefault();
        });

        // 3. Disable Keyboard Zoom Shortcuts (Ctrl/Cmd + Plus, Minus, Zero)
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.key === '-' || e.key === '=' || e.key === '0' || e.key === 'u' || e.key === 'U')) {
                e.preventDefault();
            }
        });

        // 4. Disable Wheel Zoom
        document.addEventListener('wheel', function(e) {
            if (e.ctrlKey) {
                e.preventDefault();
            }
        }, { passive: false });

        // 5. Disable Double-Tap Zoom on iOS
        let lastTouchEnd = 0;
        document.addEventListener('touchend', function(event) {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                event.preventDefault();
            }
            lastTouchEnd = now;
        }, false);
    </script>
</body>
</html>