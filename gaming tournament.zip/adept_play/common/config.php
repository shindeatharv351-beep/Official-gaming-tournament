<?php
// adept_play/common/config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = 'root';
$db_name = 'adept_play';

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    die("<div style='background:#1e293b;color:#f87171;padding:20px;font-family:sans-serif;text-align:center;'>Database connection failed. Please run <a href='install.php' style='color:#38bdf8;'>install.php</a> first.</div>");
}

// Global Currency Formatter
function formatINR($amount) {
    return '₹' . number_format((float)$amount, 2);
}

// User Authentication Guard
function checkUserAuth() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}

// Admin Authentication Guard
function checkAdminAuth() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: login.php");
        exit;
    }
}