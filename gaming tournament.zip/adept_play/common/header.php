<?php
// common/header.php
require_once __DIR__ . '/config.php';
checkUserAuth();

// Fetch current user wallet balance & status
$stmtUser = $pdo->prepare("SELECT id, username, wallet_balance, is_blocked FROM users WHERE id = ?");
$stmtUser->execute([$_SESSION['user_id']]);
$currentUser = $stmtUser->fetch();

if (!$currentUser || $currentUser['is_blocked']) {
    session_destroy();
    header("Location: login.php?blocked=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
    <!-- Updated Browser Tab Title -->
    <title>Tournament - Mobile Gaming Arena</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#f5f3ff',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                        }
                    }
                }
            }
        }
    </script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            -webkit-tap-highlight-color: transparent;
            user-select: none !important;
            -webkit-user-select: none !important;
            -ms-user-select: none !important;
        }
        body {
            touch-action: pan-x pan-y;
        }
        ::-webkit-scrollbar {
            width: 4px;
        }
        ::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 4px;
        }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 flex justify-center min-h-screen overflow-x-hidden antialiased">
    <!-- Mobile App Container Shell -->
    <div class="w-full max-w-md bg-slate-900 border-x border-slate-800/80 min-h-screen flex flex-col relative pb-24 shadow-2xl">
        
        <!-- Sticky Top Navigation -->
        <header class="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <div class="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
                    <i class="fa-solid fa-gamepad text-sm"></i>
                </div>
                <div>
                    <!-- Updated Top Header Name -->
                    <h1 class="text-base font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-200 to-amber-400 bg-clip-text text-transparent">Tournament</h1>
                </div>
            </div>

            <!-- Wallet Capsule -->
            <a href="wallet.php" class="flex items-center space-x-1.5 bg-slate-800/90 border border-slate-700/80 hover:border-amber-500/50 px-3 py-1.5 rounded-full transition-all">
                <i class="fa-solid fa-wallet text-amber-400 text-xs"></i>
                <span class="text-xs font-bold text-amber-300"><?= formatINR($currentUser['wallet_balance']) ?></span>
            </a>
        </header>

        <!-- Main Body Wrapper -->
        <main class="flex-1 px-4 py-4">