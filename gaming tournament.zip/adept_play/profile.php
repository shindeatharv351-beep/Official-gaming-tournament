<?php
// adept_play/profile.php
require_once __DIR__ . '/common/config.php';
checkUserAuth();

$userId = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Handle Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Handle Profile & Password Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $upiId    = trim($_POST['upi_id'] ?? '');

        if (empty($username) || empty($email)) {
            $message = "Username and Email cannot be empty.";
            $messageType = 'error';
        } else {
            $chk = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $chk->execute([$username, $email, $userId]);
            if ($chk->fetch()) {
                $message = "Username or Email is already taken by another account.";
                $messageType = 'error';
            } else {
                $upd = $pdo->prepare("UPDATE users SET username = ?, email = ?, upi_id = ? WHERE id = ?");
                $upd->execute([$username, $email, $upiId, $userId]);
                $_SESSION['username'] = $username;
                $message = "Profile & UPI details updated successfully!";
                $messageType = 'success';
            }
        }
    } elseif ($action === 'change_password') {
        $currentPass = $_POST['current_password'] ?? '';
        $newPass     = $_POST['new_password'] ?? '';

        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $storedHash = $stmt->fetchColumn();

        if (!password_verify($currentPass, $storedHash)) {
            $message = "Current password is incorrect.";
            $messageType = 'error';
        } elseif (strlen($newPass) < 6) {
            $message = "New password must be at least 6 characters long.";
            $messageType = 'error';
        } else {
            $newHash = password_hash($newPass, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $upd->execute([$newHash, $userId]);
            $message = "Password changed successfully!";
            $messageType = 'success';
        }
    }
}

// Reload current user info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

require_once __DIR__ . '/common/header.php';
?>

<!-- Alert Feedback -->
<?php if (!empty($message)): ?>
    <div class="mb-4 p-3 rounded-2xl text-xs flex items-center space-x-2 border <?= ($messageType === 'success') ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400' ?>">
        <i class="fa-solid <?= ($messageType === 'success') ? 'fa-circle-check' : 'fa-circle-exclamation' ?> text-sm"></i>
        <span><?= htmlspecialchars($message) ?></span>
    </div>
<?php endif; ?>

<!-- User Identity Card -->
<div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-center mb-5 shadow-lg">
    <div class="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-indigo-600 text-white flex items-center justify-center text-2xl font-black mx-auto mb-3 shadow-md shadow-indigo-600/30">
        <?= strtoupper(substr($user['username'], 0, 1)) ?>
    </div>
    <h3 class="text-base font-bold text-white"><?= htmlspecialchars($user['username']) ?></h3>
    <p class="text-xs text-slate-400"><?= htmlspecialchars($user['email']) ?></p>
    <div class="mt-3 inline-flex items-center space-x-1.5 px-3 py-1 bg-slate-950 border border-slate-800 rounded-full text-[11px] text-amber-400">
        <i class="fa-solid fa-calendar-check text-[10px]"></i>
        <span>Member since <?= date('M Y', strtotime($user['created_at'])) ?></span>
    </div>
</div>

<!-- Edit Profile Info -->
<div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 mb-4">
    <h4 class="text-xs font-bold text-white uppercase tracking-wider mb-3">Edit Details & Payout UPI</h4>
    <form method="POST" action="profile.php" class="space-y-3">
        <input type="hidden" name="action" value="update_profile">
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
        </div>
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Email Address</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
        </div>
        <div>
            <label class="block text-[11px] text-amber-400 font-bold mb-1">Your Personal UPI ID (For Withdrawals)</label>
            <input type="text" name="upi_id" value="<?= htmlspecialchars($user['upi_id'] ?? '') ?>" placeholder="e.g. mobile@upi or name@okaxis" class="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400">
            <p class="text-[10px] text-slate-500 mt-1">Required to withdraw funds directly into your bank account.</p>
        </div>
        <button type="submit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors">
            Save Details & UPI
        </button>
    </form>
</div>

<!-- Change Password -->
<div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 mb-6">
    <h4 class="text-xs font-bold text-white uppercase tracking-wider mb-3">Security & Password</h4>
    <form method="POST" action="profile.php" class="space-y-3">
        <input type="hidden" name="action" value="change_password">
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">Current Password</label>
            <input type="password" name="current_password" required class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
        </div>
        <div>
            <label class="block text-[11px] text-slate-400 mb-1">New Password (min 6 chars)</label>
            <input type="password" name="new_password" required minlength="6" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
        </div>
        <button type="submit" class="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-colors">
            Update Password
        </button>
    </form>
</div>

<!-- Logout -->
<a href="profile.php?action=logout" class="block w-full py-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-bold text-xs rounded-2xl text-center transition-colors">
    <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i> Sign Out
</a>

<?php require_once __DIR__ . '/common/bottom.php'; ?>