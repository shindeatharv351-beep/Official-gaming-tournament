<?php
// adept_play/install.php
$host = '127.0.0.1';
$user = 'root';
$pass = 'root';
$dbname = 'adept_play';

$message = '';
$status = '';

try {
    // 1. Connect without DB to create database
    $pdo = new PDO("mysql:host=$host", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE `$dbname`;");

    // 2. Create Users Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(50) NOT NULL UNIQUE,
        `email` VARCHAR(100) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `wallet_balance` DECIMAL(10,2) DEFAULT 0.00,
        `is_blocked` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    // 3. Create Admin Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `admin` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(50) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    // 4. Create Tournaments Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `tournaments` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `title` VARCHAR(150) NOT NULL,
        `game_name` VARCHAR(100) NOT NULL,
        `entry_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `prize_pool` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `commission_percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        `match_time` DATETIME NOT NULL,
        `room_id` VARCHAR(50) DEFAULT NULL,
        `room_password` VARCHAR(50) DEFAULT NULL,
        `winner_id` INT DEFAULT NULL,
        `status` ENUM('Upcoming', 'Live', 'Completed') NOT NULL DEFAULT 'Upcoming',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    // 5. Create Participants Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `participants` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `tournament_id` INT NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY `unique_participant` (`user_id`, `tournament_id`)
    ) ENGINE=InnoDB;");

    // 6. Create Transactions Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `transactions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `amount` DECIMAL(10,2) NOT NULL,
        `type` ENUM('credit', 'debit') NOT NULL,
        `description` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");

    // 7. Seed Admin User (admin / admin123)
    $stmt = $pdo->prepare("SELECT id FROM `admin` WHERE username = ?");
    $stmt->execute(['admin']);
    if (!$stmt->fetch()) {
        $adminPass = password_hash('admin123', PASSWORD_BCRYPT);
        $insertAdmin = $pdo->prepare("INSERT INTO `admin` (username, password) VALUES (?, ?)");
        $insertAdmin->execute(['admin', $adminPass]);
    }

    // Auto-redirect to login after 3 seconds or via immediate header if clean run
    header("Location: login.php?installed=1");
    exit;

} catch (PDOException $e) {
    $status = 'error';
    $message = "Database installation failed: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Adept Play - Installation</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center shadow-xl">
        <h1 class="text-2xl font-bold text-amber-500 mb-2">Adept Play Installer</h1>
        <?php if ($status === 'error'): ?>
            <div class="bg-red-500/20 text-red-400 p-4 rounded-xl text-sm border border-red-500/30 mb-4">
                <?= htmlspecialchars($message) ?>
            </div>
            <p class="text-xs text-slate-400 mb-4">Check that your MySQL credentials in `install.php` match your server (`127.0.0.1`, `root`, `root`).</p>
            <a href="install.php" class="inline-block px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-white font-medium text-sm">Retry</a>
        <?php endif; ?>
    </div>
</body>
</html>